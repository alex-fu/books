package com.wacai.fund.fs.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.client.exception.FundParentException;
import com.wacai.fund.parent.lang.utils.DESedeUtil;
import com.wacai.fund.parent.service.net.SFtpClientService;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * SFTPTransfter
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Service
public class SFTPTransfer implements Transfer {

	@Autowired
	private PropertyService propertyService;

    @Override
    public byte[] download(String folder, String fileName) {
        log.info("sftp execute download from {}/{}", folder,fileName);
		try {
			String host = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_HOST);
			int port = propertyService.getInt(PropertyConstant.FUND.CHINAAMC_SFTP_PORT);
			String username = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_USERNAME);
			String password = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_PASSWORD);
			log.info("SFTPTransfer file host {} port {} username {} password {} fileDir {} fileName {}", host,
					port, username, password, folder, fileName);

			// 从华夏SFTP下载文件
			ChannelSftp sftp = SFtpClientService.getSftpConnect(host, port, username, password);

			// 判断文件是否存在
			byte[] encryptData = null;
			if (SFtpClientService.existFile(fileName, folder, sftp)) {
				log.info("SFTPTransfer file is exist fileDir {} fileName {}", folder, fileName);
				encryptData = SFtpClientService.downloadAsByte(fileName, folder, sftp);
			}

			// 上传到Fog
			if (encryptData != null && encryptData.length > 0) {
				log.info("SFTPTransfer data is exist fileDir {} fileName {}", folder, fileName);
				// 数据解密
				String key = propertyService.getString(PropertyConstant.FUND.CHINAAMC_FILE_SECRET_KEY);
				byte[] decryptData = DESedeUtil.decryptDes3CBC(key, new String(encryptData));
				return decryptData;
			} else {
				throw FundParentException.wrap("sftp download fail failed");
			}
		} catch (Exception e) {
			log.error("SFTPTransfer file download fileName {} err", fileName, e);
			throw FundParentException.wrap("sftp download fail failed");
		}
    }

    @Override
    public void upload(String folder, String fileName) {
        log.info("sftp execute upload to {}/{}", folder,fileName);
        try {
			String host = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_HOST);
			int port = propertyService.getInt(PropertyConstant.FUND.CHINAAMC_SFTP_PORT);
			String username = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_USERNAME);
			String password = propertyService.getString(PropertyConstant.FUND.CHINAAMC_SFTP_PASSWORD);
			log.info("SFTPTransfer upload file host {} port {} username {} password {} fileDir {} fileName {}", host,
					port, username, password, folder, fileName);

			// 从华夏SFTP下载文件
			ChannelSftp sftp = SFtpClientService.getSftpConnect(host, port, username, password);

			SFtpClientService.upload(folder, fileName, sftp);
		} catch (Exception e) {
			log.error("SFTPTransfer file upload fileName {} err", fileName, e);
			throw FundParentException.wrap("sftp upload file failed");
		}
    }
    

}

package com.wacai.fund.fs.bean.output;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;

import com.wacai.fund.fs.bean.core.Field;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.ta.Model03JZ;
import com.wacai.fund.fs.enums.TAType;

import lombok.Data;

/**
 * File03JZ
 *
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class File03JZ {
    private String fileIdentifierStart;  //OFDCFDAT
    private String version;         //20
    private String fileCreator;     //152 wacai sales code
    private String fileReceiver;     //TA code
    private String tradeDate;       //20171031
    private String summarySheetNo;    //default null line
    private String fileType;          //default 03
    private String fileSender;        //152 wacai sales code
    private String receiver;      //TA code
    private String fieldLength;       //076
    private String recordNo;         //
    private String fileIdentifierEnd;         //OFDCFEND

    private List <Model03JZ> datas;

    /** the field length refer to the TA document **/
    public File03JZ(String ta, String tradeDate, List <Model03JZ> datas) {
        this.fileIdentifierStart = "OFDCFDAT";
        this.version = StringUtils.rightPad("20", 4, " ");
        this.fileCreator = StringUtils.rightPad("152", 9, " ");
        this.fileReceiver = StringUtils.rightPad(ta, 9, " ");
        this.tradeDate = StringUtils.rightPad(tradeDate, 4, " ");
        this.summarySheetNo = StringUtils.rightPad("", 3, " ");// 3 blanks
        this.fileType = "03";
        this.fileSender = StringUtils.rightPad("152", 8, " ");
        this.receiver = StringUtils.rightPad(ta, 8, " ");
        this.fieldLength = "076";
        this.fileIdentifierEnd = "OFDCFEND";
        this.datas = datas;
        this.recordNo = recordNo(datas);
    }

    public List <String> transfer() {
        List <String> lines = new ArrayList <>();
        lines.add(fileIdentifierStart);
        lines.add(version);
        lines.add(fileCreator);
        lines.add(fileReceiver);
        lines.add(tradeDate);
        lines.add(summarySheetNo);
        lines.add(fileType);
        lines.add(fileSender);
        lines.add(receiver);
        lines.add(fieldLength);
        addFields(lines);
        lines.add(recordNo);
        addData(lines);
        lines.add(fileIdentifierEnd);
        return lines;
    }

    private void addFields(List <String> lines) {
        Template template = new Template(TAType.TA_03JZ);
        List <String> fields = template.getFields().stream().map(Field::getName).collect(Collectors.toList());
        fields.stream().forEach(lines::add);
    }

    private void addData(List <String> lines) {
        datas.stream().map(Model03JZ::toString).forEach(lines::add);
    }

    private String recordNo(List <Model03JZ> datas) {
        return StringUtils.leftPad(String.valueOf(datas.size()), 8, "0");
    }
}

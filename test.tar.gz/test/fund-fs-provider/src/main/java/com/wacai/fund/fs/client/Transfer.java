package com.wacai.fund.fs.client;

public interface Transfer {
    byte[] download(String folder, String fileName)throws Exception;

    void upload(String folder, String fileName)throws Exception;
}

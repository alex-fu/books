package com.wacai.fund.fs.enums;

/**
 * SystemType
 *
 * @author mufu
 * @date 2017/11/04
 */
public enum SystemType {
    TA(1, "TA系统"),
    FS(2, "文件系统"),
    AS(3, "账户系统"),
    SXB(4, "生息宝交易系统"),
    JZ(5, "金证系统"),
    PCS(6, "产品中心系统"),
    HX(7, "华夏系统"),
    MS(8, "资金系统"),
    PAYMENT(9, "支付系统");


    private final Integer value;
    private final String type;

    private SystemType(Integer value, String type) {
        this.value = value;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static SystemType getInstance(Integer value) {
        for (SystemType system : values()) {
            if (system.value.equals(value)) {
                return system;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

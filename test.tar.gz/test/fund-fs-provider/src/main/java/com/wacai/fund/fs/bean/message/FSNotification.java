package com.wacai.fund.fs.bean.message;

import lombok.Data;

/**
 * FSNotification
 *
 * @author mufu
 * @date 2017/11/17
 */
@Data
public class FSNotification {
    /** task Id**/
    String taskId;

    /** ta code **/
    String taCode;

    /** trade date **/
    String tradeDate;

    /** file group **/
    String fileGroup;

    /** file name **/
    String fileName;

    /** file type **/
    Integer fileType;
}

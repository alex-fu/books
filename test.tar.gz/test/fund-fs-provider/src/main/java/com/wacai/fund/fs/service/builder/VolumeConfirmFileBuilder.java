package com.wacai.fund.fs.service.builder;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.output.VolConfirm;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.service.ta.VolumeConfirmService;

import lombok.extern.slf4j.Slf4j;

/**
 * VolumeConfirmFileBuilder
 *
 * @author mufu
 * @date 2017/11/27
 */
@Slf4j
@Service("volumeConfirmFileBuilder")
public class VolumeConfirmFileBuilder extends AbstractFileBuilder {

    private static final Template TEMPLATE = new Template(TAType.TA_05);

    private static final TAParser TA_PARSER = TAParser.getInstance();

    private TABeans<TA> tab05;

    @Autowired
    @Qualifier("volumeConfirmServiceImpl")
    VolumeConfirmService volConfirmService;

    @Override
    protected void init()throws Exception{
        tab05 = TA_PARSER.buildFromTA(getSource(), TEMPLATE);
        log.info("VolumeConfirm FileBuilder build init successful!!!");
    }

    @Override
    public List<String> fetch() {
        List <String> lines = new ArrayList<>();
        List<VolConfirm> tc05 = volConfirmService.convert(tab05);
        tc05.stream().map(VolConfirm::toString).forEach(lines::add);
        return lines;
    }

    @Override
    public Path buildPath() {
        File file = new File(getSource());
        Path path = Paths.get(file.getParent(), getDist());
        log.info("the file = {}",path.getFileName());
        return path;
    }
}

package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * Model05 class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model05 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5928079075721334628L;

	private BigDecimal AvailableVol;
	private BigDecimal TotalVolOfDistributorInTA;
	private String TransactionCfmDate;
	private String FundCode;
	private String TransactionAccountID;
	private String DistributorCode;
	private String TAAccountID;
	private BigDecimal TotalFrozenVol;
	private String BranchCode;
	private String TASerialNO;
	private BigDecimal TotalBackendLoad;
	private String ShareClass;
	private String DetailFlag;
	private String AccountStatus;
	private String ShareRegisterDate;
	private BigDecimal UndistributeMonetaryIncome;
	private String UndistributeMonetaryIncomeFlag;
	private BigDecimal GuaranteedAmount;
	private String SourceType;
	private String DefDividendMethod;

}

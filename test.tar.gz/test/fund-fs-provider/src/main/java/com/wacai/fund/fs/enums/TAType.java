package com.wacai.fund.fs.enums;

import com.wacai.fund.fs.bean.ta.Model02;
import com.wacai.fund.fs.bean.ta.Model03;
import com.wacai.fund.fs.bean.ta.Model03JZ;
import com.wacai.fund.fs.bean.ta.Model04;
import com.wacai.fund.fs.bean.ta.Model05;
import com.wacai.fund.fs.bean.ta.Model06;
import com.wacai.fund.fs.bean.ta.Model07;

/**
 * TAType enum
 *
 * @author mufu
 * @date 2017/11/31
 */
public enum TAType {
    TA_02(2, "TA02", Model02.class),
    TA_03(3, "TA03", Model03.class),
    TA_04(4, "TA04", Model04.class),
    TA_05(5, "TA05", Model05.class),
    TA_06(6, "TA06", Model06.class),
    TA_07(7, "TA07", Model07.class),
    TA_03JZ(8, "TA03JZ", Model03JZ.class);

    private final Integer value;
    private final String desc;
    private final Class ta;

    private TAType(Integer value, String desc, Class ta) {
        this.value = value;
        this.desc = desc;
        this.ta = ta;
    }

    public String getDesc() {
        return desc;
    }

    public Class getTA() {
        return ta;
    }

    public static TAType getInstance(Integer value) {
        for (TAType ta : values()) {
            if (ta.value.equals(value)) {
                return ta;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

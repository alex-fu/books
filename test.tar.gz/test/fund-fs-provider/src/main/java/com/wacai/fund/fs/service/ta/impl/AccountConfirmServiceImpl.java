package com.wacai.fund.fs.service.ta.impl;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.AccountConfirm;
import com.wacai.fund.fs.bean.ta.Model02;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.service.ta.AccountConfirmService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * AccountConfirmServiceImpl
 *
 * @author mufu
 * @date 2017/11/17
 */
@Service
public class AccountConfirmServiceImpl implements AccountConfirmService {
    @Override
    public List <AccountConfirm> convert(TABeans <TA> ta02) {
        List <AccountConfirm> acs = new ArrayList <>();
        List <TA> m02s = ta02.getTas();
        for (TA t : m02s) {
            AccountConfirm ac = new AccountConfirm();
            Model02 m02 = (Model02) t;
            ac.setAckDate(m02.getTransactionCfmDate());
            ac.setTradeAccount(m02.getTransactionAccountID());
            ac.setFundAccount(m02.getTAAccountID());
            ac.setBusiCode(m02.getBusinessCode());
            ac.setTaCode(ta02.getTa());
            ac.setTaRetCode(m02.getReturnCode());
            ac.setRetMsg(m02.getSpecification());
            acs.add(ac);
        }
        return acs;
    }
}

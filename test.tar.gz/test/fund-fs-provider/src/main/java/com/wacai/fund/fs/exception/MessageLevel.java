package com.wacai.fund.fs.exception;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * MessageLevel enum
 *
 * @author mufu
 * @date 2017/11/06
 */
public enum MessageLevel {

    UNKNOWN(0, "unknow"),
    FATAL(1, "fatal"),
    ERROR(2, "error"),
    WARNING(3, "warning"),
    INFO(4, "info");

    public final Integer value;
    public final String description;

    private MessageLevel(Integer value, String description) {
        this.value = value;
        this.description = description;
    }

    @JsonCreator
    public static MessageLevel getInstance(Integer value) {
        for (MessageLevel errorType : values()) {
            if (errorType.value.equals(value)) {
                return errorType;
            }
        }
        return null;
    }

    @JsonValue
    public Integer getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}
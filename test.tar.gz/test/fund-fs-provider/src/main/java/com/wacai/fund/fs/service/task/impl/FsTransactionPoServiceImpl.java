package com.wacai.fund.fs.service.task.impl;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.FSExceptionCode;
import com.wacai.fund.fs.exception.FSException;
import com.wacai.fund.fs.mapper.FsTransactionMapper;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.service.task.Template2TransactionService;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TaskTransactionServiceImpl
 *
 * @author mufu
 * @date 2017/11/17
 */

@Service
@Slf4j
public class FsTransactionPoServiceImpl implements FsTransactionPoService {


    @Autowired
    Template2TransactionService template2TransactionService;

    @Autowired
    FsTransactionMapper fsTransactionMapper;

    @Override
    public void createtTransaction(List <FsTemplatePo> templates)throws FSException {
        if (CollectionUtils.isEmpty(templates)) {
            throw new FSException(FsTransactionPoServiceImpl.class, FSExceptionCode.CODE_0004);
        }

        List <FsTransactionPo> fsTransactionPos = new ArrayList <>();

		for (FsTemplatePo template : templates) {
			FsTransactionPo fsTransactionPo = template2TransactionService.generate(template);
			if (StringUtils.isNoneBlank(fsTransactionPo.getTaskId())) {
				fsTransactionPos.add(fsTransactionPo);
			}
		}
        List <FsTransactionPo> needToCreateTaskTransactions = fsTransactionPos.stream().filter(e->!isAvailable(e.getTaskId())).collect(Collectors.toList());
        for (FsTransactionPo fsTransactionPo : needToCreateTaskTransactions) {
            fsTransactionMapper.insert(fsTransactionPo);
            log.info("create transaction {} successful!!!", fsTransactionPo.getTaskName());
        }
    }



    @Override
    public FsTransactionPo get(Long id) {
        FsTransactionPo fsTransactionPo = fsTransactionMapper.selectByPrimaryKey(id);
        return fsTransactionPo;
    }

    @Override
    public FsTransactionPo getByTaskId(String taskId) {
        FsTransactionPo fsTransactionPo = fsTransactionMapper.selectByTaskId(taskId);
        return fsTransactionPo;
    }

    @Override
    public int update(FsTransactionPo fsTransactionPo) {
        return fsTransactionMapper.update(fsTransactionPo);
    }

    @Override
    public boolean isAvailable(String taskId) {
        FsTransactionPo fsTransactionPo = fsTransactionMapper.selectByTaskId(taskId);
        return fsTransactionPo!=null?true:false;
    }
}

package com.wacai.fund.fs.constant;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.fund.fs.utils.DateUtils;
import com.wacai.fund.fs.utils.FileUtils;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * SystemConstant class
 *
 * @author mufu
 * @date 2017/11/01
 */
@Component
@Data
@Slf4j
public class SystemConstant implements InitializingBean {
	
	public static final String WINDOW_LINE_SEPARATOR = "\r\n";

    public static final String LINUX_LINE_SEPARATOR = "\n";

    public static final String LATIN_ENCODING = "ISO-8859-1";

    public static final String GBK_ENCODING = "GBK";
    
    public static final String UTF8_ENCODING = "UTF-8";
    
    public static final String FUND_FS_MGMT_PROCESS = "fund_fs_mgmt_process";
    
    public static final String FUND_FS_MGMT_CALLBACK = "fund_fs_mgmt_callback";
    
    public static final String FUND_FILE_SYSTEM = "fundFs";
    
    public static final String CREATE_JOB = "createJob";
    
    public static final String SEND_MESSAGE = "sendMessage";
    
    public static final String JOB_CONFIRM = "jobConfirm";
    
    public static final String UNCONFIRMED = "unconfirmed";
    
    public static final String CALLBACK = "callback";
    
    public static final String DOWNLOAD = "download";
    
    public static final String UPLOAD = "upload";
    
    public static final String SUCCES = "succes";
    
    public static final String FAILED = "failed";

    public static final Integer DEFAULT_BUFFERSIZE = 1024 * 10;

    @Autowired
	private PropertyService propertyService;

    /**
     * read from properties, if no properties, use default
     */
    @PostConstruct
    public void init() {
        String downloadPath = propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH, "/data/program/download");
        
        Path path = Paths.get(downloadPath);
        log.info("the base folder is {}", path.toFile().getAbsolutePath());
        try {
            if (!path.toFile().exists()) {
                FileUtils.createDirectory(path);
            }
            Path today = Paths.get(downloadPath, DateUtils.getCurrentDate());
            if (!path.toFile().exists()) {
                FileUtils.createDirectory(today);
            }
        } catch (IOException e) {
            log.error("create folder failed, reason {}", e);
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("The DOWNLOAD folder setting {}", propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH, "/data/program/download"));
    }
}

package com.wacai.fund.fs.service.task;

import com.wacai.fund.fs.bean.task.FsTemplatePo;

import java.util.List;

/**
 * FsTemplatePoService
 *
 * @author mufu
 * @date 2017/11/17
 */
public interface FsTemplatePoService {
     List<FsTemplatePo> getAllTemplate() ;
}

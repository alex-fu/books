package com.wacai.fund.fs.enums;

/**
 * TaskType enum
 *
 * @author mufu
 * @date 2017/11/28
 */
public enum TaskType {
    TASK_1(1, "02文件生成账户确认文件"),
    TASK_2(2, "04、06生成交易确认文件"),
    TASK_3(3, "05文件生成份额对账文件"),
    TASK_4(4, "07文件"),
    TASK_5(5, "03金证文件"),
    TASK_6(6,"华夏F004文件"),
    TASK_7(7,"华夏F011文件"),
    TASK_8(8, "华安07文件"),
    TASK_9(9, "华安份额划转文件"),
    TASK_10(10, "华安份额划转结果文件");


    private final Integer value;
    private final String type;

    private TaskType(Integer value, String type) {
        this.value = value;
        this.type = type;
    }

    public Integer getValue() {
        return value;
    }

    public String getType() {
        return type;
    }

    public static TaskType getInstance(Integer value) {
        for (TaskType channel : values()) {
            if (channel.value.equals(value)) {
                return channel;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

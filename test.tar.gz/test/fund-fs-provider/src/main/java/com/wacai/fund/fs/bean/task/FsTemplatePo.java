package com.wacai.fund.fs.bean.task;


import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>任务模板表的实体类</p>
 * <p>Table: fs_template - 任务模板表</p>
 * 
 * @since 2017-11-23 08:24:44
 */
@Data
public class FsTemplatePo implements Serializable{

    private static final long serialVersionUID = -2348805088257570429L;
    /** id -  */
    private Long id;
	
	/** task_name -  */
    private String taskName;

    /** task_type **/
    private Integer taskType;
	
	/** provider -  */
    private Integer provider;
	
	/** provider_path -  */
    private String providerPath;
	
	/** receiver -  */
    private Integer receiver;
	
	/** receiver_path -  */
    private String receiverPath;
	
	/** download -  */
    private Boolean downloadStatus;
	
	/** upload -  */
    private Boolean uploadStatus;
	
	/** day_type -  */
    private Integer dayType;
	
	/** file_dt -  */
    private Integer fileDt;
	
	/** download_file_pattern -  */
    private String downloadFilePattern;

    /** upload_file_pattern -  */
    private String uploadFilePattern;

    /** file type- */
    private Integer fileType;
	
	/** remark -  */
    private String remark;
	
	/** execution_dt -  */
    private String executionDt;
	
	/** wait_ack_time -  */
    private Integer waitAckTime;
	
	/** status -  */
    private Boolean status;
	
	/** created_time - 创建时间 */
    private Date createdTime;
	
	/** updated_time - 修改时间 */
    private Date updatedTime;

}
package com.wacai.fund.fs.constant;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import com.wacai.fund.fs.bean.ta.Model02;
import com.wacai.fund.fs.bean.ta.Model03;
import com.wacai.fund.fs.bean.ta.Model03JZ;
import com.wacai.fund.fs.bean.ta.Model04;
import com.wacai.fund.fs.bean.ta.Model05;
import com.wacai.fund.fs.bean.ta.Model06;
import com.wacai.fund.fs.bean.ta.Model07;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.parent.client.enums.FileSysOutputTypeEnum;
import com.wacai.fund.parent.monitor.enums.ActionEnum;


/**
 * TaConstant class
 *
 * @author mufu
 * @date 2017/11/31
 */
@SuppressWarnings("rawtypes")
public class TaConstant {

	public static final String PREFIX = "META-INF/config/";

	public static final String TA02 = PREFIX + "02.json";

	public static final String TA03 = PREFIX + "03.json";

	public static final String TA04 = PREFIX + "04.json";

	public static final String TA05 = PREFIX + "05.json";

	public static final String TA06 = PREFIX + "06.json";

	public static final String TA07 = PREFIX + "07.json";

	public static final String TA03JZ = PREFIX + "03jz.json";

    protected static Map <TAType, String> taMap = new EnumMap<>(TAType.class);

	protected static Map<TAType, Class> taMapClass = new EnumMap<>(TAType.class);
	
	//文件系统监控风险点action列表
	protected static Map <String, String> monitorActionMap = new HashMap<>();

    static {
    	taMap.put(TAType.TA_02, TA02);
    	taMap.put(TAType.TA_03, TA03);
    	taMap.put(TAType.TA_04, TA04);
    	taMap.put(TAType.TA_05, TA05);
    	taMap.put(TAType.TA_06, TA06);
    	taMap.put(TAType.TA_07, TA07);
    	taMap.put(TAType.TA_07, TA07);
    	taMap.put(TAType.TA_03JZ, TA03JZ);

    	taMapClass.put(TAType.TA_02, Model02.class);
    	taMapClass.put(TAType.TA_03, Model03.class);
    	taMapClass.put(TAType.TA_04, Model04.class);
    	taMapClass.put(TAType.TA_05, Model05.class);
    	taMapClass.put(TAType.TA_06, Model06.class);
    	taMapClass.put(TAType.TA_07, Model07.class);
    	taMapClass.put(TAType.TA_03JZ, Model03JZ.class);
    	
    	monitorActionMap.put(FileSysOutputTypeEnum.ACC_ACK.getCode() +"_detection", ActionEnum.DETECTION_ACCOUNT_CONFIRM_FILE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.ACC_ACK.getCode() +"_download", ActionEnum.ACCOUNT_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.ACC_ACK.getCode() +"_upload", ActionEnum.ACCOUNT_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.ACC_ACK.getCode() +"_message", ActionEnum.ACCOUNT_CONFIRM_MESSAGE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.ACC_ACK.getCode() +"_callback", ActionEnum.ACCOUNT_CONFIRM_CALLBACK.getCode());
    	
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_APP.getCode() +"_detection", ActionEnum.DETECTION_TRADE_APP_FILE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_APP.getCode() +"_download", ActionEnum.TRADE_APP_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_APP.getCode() +"_upload", ActionEnum.TRADE_APP_PROCESS.getCode());
    	
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_ACK.getCode() +"_detection", ActionEnum.DETECTION_TRADE_CONFIRM_FILE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_ACK.getCode() +"_download", ActionEnum.TRADE_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_ACK.getCode() +"_upload", ActionEnum.TRADE_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_ACK.getCode() +"_message", ActionEnum.TRADE_CONFIRM_MESSAGE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.TRA_ACK.getCode() +"_callback", ActionEnum.TRADE_CONFIRM_CALLBACK.getCode());
    	
    	monitorActionMap.put(FileSysOutputTypeEnum.VOL_CHK.getCode() +"_detection", ActionEnum.DETECTION_VOL_CONFIRM_FILE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.VOL_CHK.getCode() +"_download", ActionEnum.VOL_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.VOL_CHK.getCode() +"_upload", ActionEnum.VOL_CONFIRM_PROCESS.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.VOL_CHK.getCode() +"_message", ActionEnum.VOL_CONFIRM_MESSAGE.getCode());
    	monitorActionMap.put(FileSysOutputTypeEnum.VOL_CHK.getCode() +"_callback", ActionEnum.VOL_CONFIRM_CALLBACK.getCode());
    	
       	monitorActionMap.put(FileSysOutputTypeEnum.TA_07.getCode() +"_detection", ActionEnum.DETECTION_FUND_INFO_FILE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.TA_07.getCode() +"_download", ActionEnum.FUND_INFO_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.TA_07.getCode() +"_upload", ActionEnum.FUND_INFO_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.TA_07.getCode() +"_message", ActionEnum.FUND_INFO_MESSAGE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.TA_07.getCode() +"_callback", ActionEnum.FUND_INFO_CALLBACK.getCode());

        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode() +"_detection", ActionEnum.DETECTION_BAL_TRANSFER_EXPORT_FILE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode() +"_download", ActionEnum.BAL_TRANSFER_EXPORT_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode() +"_upload", ActionEnum.BAL_TRANSFER_EXPORT_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode() +"_message", ActionEnum.BAL_TRANSFER_EXPORT_MESSAGE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode() +"_callback", ActionEnum.BAL_TRANSFER_EXPORT_CALLBACK.getCode());

        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode() +"_detection", ActionEnum.DETECTION_BAL_TRANSFER_IMPORT_FILE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode() +"_download", ActionEnum.BAL_TRANSFER_IMPORT_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode() +"_upload", ActionEnum.BAL_TRANSFER_IMPORT_PROCESS.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode() +"_message", ActionEnum.BAL_TRANSFER_IMPORT_MESSAGE.getCode());
        monitorActionMap.put(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode() +"_callback", ActionEnum.BAL_TRANSFER_IMPORT_CALLBACK.getCode());
    }
    
    private TaConstant() {
	}
    
    public static Map<TAType, String> getTaMap() {
		return taMap;
	}

	public static Map<TAType, Class> getTaMapClass() {
		return taMapClass;
	}

	public static Map<String, String> getMonitorActionMap() {
		return monitorActionMap;
	}
	
}


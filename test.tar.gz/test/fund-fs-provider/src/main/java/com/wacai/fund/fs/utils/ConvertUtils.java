package com.wacai.fund.fs.utils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.Assert;

import com.wacai.fund.fs.bean.core.Field;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.constant.SystemConstant;

import lombok.extern.slf4j.Slf4j;


/**
 * ConvertUtils class
 *
 * @author mufu
 * @date 2017/10/31
 */
@Slf4j
public class ConvertUtils {
	
	private ConvertUtils() {
		
	}

    public static Object convert(Field field, String value) throws Exception {
        log.debug("convert : Field Type is {} and value {}", field.getType(), value);
        Assert.notNull(field, "must be not null");
        switch (field.getType().toUpperCase()) {
            case "C":
                log.debug("default decode to GBK");
                log.debug(new String(value.getBytes(SystemConstant.LATIN_ENCODING), SystemConstant.GBK_ENCODING));
                return new String(value.getBytes(SystemConstant.LATIN_ENCODING), SystemConstant.GBK_ENCODING).trim();
            case "A":
                return value.trim();
            case "N":
                String start = value.substring(0, value.length() - field.getPrecision());
                String end = value.substring(value.length() - field.getPrecision(), value.length());
                String valueString = start + "." + end;
                return new BigDecimal(valueString);
            default:
                throw new Exception("type convert error!!!");
        }
    }

    public static Object convertObject(Field field, String value) throws Exception {
        log.debug("convertObject : Field Type is {} and value {}", field.getType(), value);
        Optional <String> valueOptional = Optional.ofNullable(value);
        String valueString = valueOptional.orElse("");
        switch (field.getType().toUpperCase()) {
            case "C":
            case "A":
                return valueString.trim();
            case "N":
                if (StringUtils.isBlank(valueString)) {
                	valueString = StringUtils.rightPad("0.", field.getPrecision(), "0");
                }
                return new BigDecimal(valueString);
            default:
                throw new Exception("type convertObject error!!!");
        }
    }

    public static String convertReverse(Field field, Object value) throws Exception {
        log.debug("convertReverse : Field Type is {}, length is {}, precision is {}  and value is {}", field.getType(), field.getLength(), field.getPrecision(), value);
        Optional <Object> valueOptional = Optional.ofNullable(value);
        switch (field.getType().toUpperCase()) {
            case "C":
                String valueString = (String) valueOptional.orElse("");
                valueString = new String(valueString.getBytes(SystemConstant.UTF8_ENCODING), SystemConstant.LATIN_ENCODING).trim();
                return StringUtils.rightPad(valueString, field.getLength(), " ");
            case "A":
                valueString = (String) valueOptional.orElse("");
                valueString = valueString.trim();
                return StringUtils.rightPad(valueString, field.getLength(), " ");
            case "N":
                valueString = value.toString().trim().replace(".", "");
                valueString = StringUtils.leftPad(valueString, field.getLength(), "0");
                return valueString;
            default:
                throw new Exception("type convertReverse error!!!");
        }
    }

    public static int convertToCent(BigDecimal bg) {
        return bg.multiply(new BigDecimal(100)).intValue();
    }

    public static Object mapToObject(Map <String, Object> maps, Class <?> beanClass) throws Exception {
        Object obj = beanClass.newInstance();
        BeanInfo beanInfo = Introspector.getBeanInfo(beanClass);
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (PropertyDescriptor property : propertyDescriptors) {
            String key = property.getName();
            key = StringUtils.capitalize(key);
            if (maps.containsKey(key)) {
                Object value = maps.get(key);
                Method setter = property.getWriteMethod();
                setter.invoke(obj, value);
            }
        }
        return obj;
    }

    public static Object mapToObject2(Map <String, Object> map, Class <?> beanClass) throws Exception {
        if (map == null) {
            return null;
        }
        Object obj = beanClass.newInstance();
        BeanUtils.populate(obj, map);
        return obj;
    }

    public static Object mapToObject3(Map <String, Object> map, Class <?> beanClass) throws Exception {
        if (map == null) {
            return null;
        }
        Object obj = beanClass.newInstance();
        java.lang.reflect.Field[] fields = obj.getClass().getDeclaredFields();
        Arrays.stream(fields).filter(filed -> !(Modifier.isStatic(filed.getModifiers()) && Modifier.isFinal(filed.getModifiers()))).forEach(field -> {
            try {
                field.setAccessible(true);
                field.set(obj, map.get(field.getName()));
            } catch (IllegalAccessException e) {
                log.error("mapToObject3 happen Exception", e);
            }
        });
        return obj;
    }

    public static Map <String, Object> objectToMap(Object obj) throws Exception {
        if (obj == null) {
            return null;
        }
        Map <String, Object> map = new LinkedHashMap <>();
        BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (PropertyDescriptor property : propertyDescriptors) {
            String key = property.getName();
            if (key.compareToIgnoreCase("class") == 0) {
                continue;
            }
            Method getter = property.getReadMethod();
            Object value = getter != null ? getter.invoke(obj) : null;
            key = StringUtils.capitalize(key);
            map.put(key, value);
        }

        return map;
    }

    public static Map <String, Object> objectToMap(Object obj, Template template) throws Exception {
        if (obj == null) {
            return null;
        }
        List <Field> fields = template.getFields();
        Map <String, Object> map = new LinkedHashMap <>();
        for (Field field : fields) {
            map.put(field.getName(), BeanUtils.getProperty(obj, field.getName()));
        }
        return map;
    }

    public static Map <String, Object> objectToMap2(Object obj) throws Exception {
        if (obj == null) {
            return null;
        }
        Map <String, Object> map = new HashMap <>();
        java.lang.reflect.Field[] declaredFields = obj.getClass().getDeclaredFields();
        for (java.lang.reflect.Field field : declaredFields) {
            field.setAccessible(true);
            map.put(field.getName(), field.get(obj));
        }
        return map;
    }

    public static Map <String, Object> sortAsField(TA ta, Template template) {
        Map <String, Object> map = new LinkedHashMap<>();
        try {
            Map<String, Object> taMap = objectToMap(ta);
            template.getFields().stream().forEach(field -> {
                Object value = taMap.get(field.getName());
                log.debug("key={},value={}", field.getName(), value);
                map.put(field.getName(), value);
            });
        } catch (Exception e) {
            log.error("sortAsField happen Exception", e);
        }
        return map;
    }

    public static Map<String, Object> sortAsFieldWithOriginalValue(TA ta, Template template){
        Map<String, Object> newMap = new LinkedHashMap<>();
        Map<String, Object> oldMap = sortAsField(ta,template);
        template.getFields().stream().forEach(field -> {
            try {
                newMap.put(field.getName(),convertReverse(field,oldMap.get(field.getName())));
            } catch (Exception e) {
                log.error("sortAsFieldWithOriginalValue happen Exception", e);
            }
        });
        return newMap;
    }

}

package com.wacai.fund.fs.service.ta;

import java.util.List;
import java.util.Optional;

import com.wacai.fund.account.api.FundCustInfoService;
import com.wacai.fund.account.dto.FundCustInfoDto;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.VolConfirm;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.parent.client.result.Result;

/**
 * TradeConfirmService interface
 *
 * @author mufu
 * @date 2017/10/7
 */
public interface VolumeConfirmService {
    public List<VolConfirm> convert(TABeans<TA> ta);

	default Long fetchUID(FundCustInfoService fundCustInfoService, String tradeAccount) {
		Result<FundCustInfoDto> fundCustInfoDtoResult = null;
		fundCustInfoDtoResult = fundCustInfoService.getFundCustInfo(tradeAccount);

		return Optional.ofNullable(fundCustInfoDtoResult).map(Result<FundCustInfoDto>::getValue)
				.map(FundCustInfoDto::getUid).orElse(123L);
	}
}

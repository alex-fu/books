package com.wacai.fund.fs.service.builder;

import com.wacai.fund.fs.service.builder.FileBuilder;
import lombok.Data;

import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.springframework.util.StringUtils.isEmpty;

/**
 * AbstractFileBuilder
 *
 * @author mufu
 * @date 2017/11/27
 */
@Data
public abstract class AbstractFileBuilder implements FileBuilder {
    private String source;
    private String dist;

    public void build(String source, String dist) throws Exception{
        setSource(source);
        setDist(dist);
        check();
        init();
        build();
    }

    protected void check()throws Exception{
        if (isEmpty(getSource()) || Files.notExists(Paths.get(getSource()))) {
            throw new FileNotFoundException("source file" + getSource() + " not exists!!!");
        }
        if(isEmpty(getDist())){
            throw new Exception("dist file should be set!!!");
        }
    }

    protected abstract void init()throws  Exception;

}

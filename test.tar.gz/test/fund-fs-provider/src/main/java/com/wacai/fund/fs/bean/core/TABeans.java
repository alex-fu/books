package com.wacai.fund.fs.bean.core;

import com.wacai.fund.fs.enums.TAType;
import lombok.Data;

import java.util.List;

/**
 * TABeans class
 *
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class TABeans<TA> {
    private String ta;

    private String sa;

    private String tradeDate;

    private TAType type;

    private List <TA> tas;

}

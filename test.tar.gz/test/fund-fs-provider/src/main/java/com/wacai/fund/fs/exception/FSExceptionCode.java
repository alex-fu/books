package com.wacai.fund.fs.exception;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * FSExceptionCode
 *
 * @author mufu
 * @date 2017/11/06
 */
public enum FSExceptionCode {

    CODE_1010001("D01_0001", "File not available"),
    CODE_1010002("D01_0002", "Network Error"),
    CODE_1010003("D01_0003", "Unknown Error");

    public final String value;
    public final String description;

    private FSExceptionCode(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public static FSExceptionCode getInstance(String value) {
        for (FSExceptionCode code : values()) {
            if (code.value == value) {
                return code;
            }
        }

        return null;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}

package com.wacai.fund.fs.service.task.impl;

import java.io.File;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.wacai.finance.share.fund.entity.tradedt.FundWorkDay;
import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.finance.share.fund.workdt.FundWorkDayService;
import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.ChannelType;
import com.wacai.fund.fs.enums.DateType;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.service.task.Template2TransactionService;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.lang.utils.DateUtil;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * Template2TransactionServiceImpl
 *
 * @author mufu
 * @date 2017/11/17
 */
@Slf4j
@Service
public class Template2TransactionServiceImpl implements Template2TransactionService {

    @Autowired
    private FundTradeDayService fundTradeDayService;
    
    @Autowired
    private FundWorkDayService fundWorkDayService;
    
    @Autowired
	private PropertyService propertyService;
    
    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Override
    public FsTransactionPo generate(FsTemplatePo template) {
        Optional <FsTemplatePo> tt = Optional.of(template);
        FsTransactionPo transaction = new FsTransactionPo();
        String taskId = getTaskId(template);
        //当任务未创建时，创建任务;任务已经存在不创建任务
        boolean isAvailable = fsTransactionPoService.isAvailable(taskId);
		if (!isAvailable && tt.isPresent() && StringUtils.isNoneBlank(taskId)) {
            transaction.setTaskId(taskId);
            transaction.setTaskName(template.getTaskName());
            transaction.setProvider(template.getProvider());
            transaction.setReceiver(template.getReceiver());
            transaction.setDownloadStatus(template.getDownloadStatus());
            /***
             *  build provider path from
             */
            if (ChannelType.FOG.getValue().compareTo(transaction.getProvider()) != 0) {
                transaction.setProviderPath(convertPath(template.getDayType(), template.getProviderPath(), ChannelType.getInstance(template.getProvider())));
            } else {
                transaction.setProviderPath(template.getProviderPath());
            }
            transaction.setReceiver(template.getReceiver());
            if (ChannelType.FOG.getValue().compareTo(transaction.getReceiver()) != 0) {
                transaction.setReceiverPath(convertPath(template.getDayType(), template.getReceiverPath(), ChannelType.getInstance(template.getReceiver())));
            }
            transaction.setUploadStatus(template.getUploadStatus());
            transaction.setDownloadFilePattern(convertTaskFileName(template.getDayType(), template.getDownloadFilePattern()));
            transaction.setUploadFilePattern(convertTaskFileName(template.getDayType(), template.getUploadFilePattern()));
            transaction.setFileType(template.getFileType());
            transaction.setWaitAckTime(template.getWaitAckTime());

            transaction.setFinishStatus(false);
            transaction.setConfirmStatus(ConfirmType.UNCONFIRMED.getValue());//unconfirmed as initialization status
            transaction.setFileType(template.getFileType());
            transaction.setAlertStatus(false);
            transaction.setLockStatus(false);
        }
        return transaction;
    }

    /**
     * @param pattern
     * @return
     * @parm fileDt  0->T, -1->T-1
     */
    private String convertTaskFileName(Integer dayType, String pattern) {
    	String taskDate = getTaskDate(dayType);
        final String finalTaskDate = taskDate;
        List <String> files = Splitter.on(",").splitToList(pattern);
        List <String> newFiles = new ArrayList <>();
		files.stream().forEach(e -> newFiles.add(convertFileName(e, finalTaskDate)));
        return Joiner.on(",").useForNull("").join(newFiles);
    }

    private String convertFileName(String pattern, String... values) {
        return MessageFormat.format(pattern, values);
    }

    private String convertPath(Integer dayType, String path, ChannelType channel) {
        String taskDate = getTaskDate(dayType);
        if (channel == ChannelType.FS) {
            return getPathWithSeparator(propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH,"/data/program/download")) + taskDate;
        }
        if (channel == ChannelType.FOG) {
            return "";
        }
        return getPathWithSeparator(path) + taskDate;
    }

    /**
     * transfer path with separator("/"), use in sftp or ftp
     * @param path
     * @return
     */
    private static String getPathWithSeparator(String path){
        Assert.notNull(path, "The path must be not null");
        return path + (path.endsWith("/")?"":File.separator);
    }
    
    /**
     * 
     * getTaskId:获取文件系统任务日期
     * @param template
     * @return
     * @author qingniu
     * @date 2017年12月18日 下午6:50:00
     */
	public String getTaskDate(Integer dayType) {
		String taskDate = "";
		String currentDate = DateUtil.currentDate();
		try {
			if (DateType.TRADE_DT.getValue().equals(dayType)) {
				String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
				if (StringUtils.isNotBlank(tradeDate)) {
					taskDate = tradeDate;
				}
				log.info("getTaskDate : dayType =={}; tradeDate  == {}", dayType, tradeDate);
			} else if (DateType.WORK_DT.getValue().equals(dayType)) {
				FundWorkDay fundWorkDay = fundWorkDayService.calFundWorkDay();
				String workDate = fundWorkDay == null ? "" : fundWorkDay.getCurWorkDt();
				if (StringUtils.isNotBlank(workDate)) {
					taskDate = workDate;
				}
				log.info("getTaskDate : dayType =={}; workDate  == {}", dayType, workDate);
			} else {
				taskDate = currentDate;
			}
			log.info("getTaskDate : dayType =={}; taskDate  == {}", dayType, taskDate);
		} catch (Exception e) {
			log.error("getTaskDate happen Exception", e);
		}
		return taskDate;
	}
    
    /**
     * 
     * getTaskId:获取文件系统任务id
     * @param template
     * @return
     * @author qingniu
     * @date 2017年12月18日 下午6:50:00
     */
	public String getTaskId(FsTemplatePo template) {
		String taskId = "";
		String taskDate = getTaskDate(template.getDayType());
		if (StringUtils.isNotBlank(taskDate)) {
			taskId = taskDate + template.getTaskType().toString();
			log.info("getTaskId : taskId  == {}", taskId);
		}
		return taskId;
	}
}

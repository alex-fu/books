package com.wacai.fund.fs.exception;

import com.wacai.fund.fs.enums.FSExceptionCode;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * FSException class
 *
 * @author mufu
 * @date 2017/11/06
 */
public class FSException extends Exception {

	private static final long serialVersionUID = 5339204251613482742L;

	private FSExceptionCode code;

    protected String message;

    protected Class <?> clazz;

    protected Throwable throwable;

    private String stringCode;

    protected FSException(Class <?> clazz) {
        this.clazz = clazz;
    }

    protected FSException(String message, Object... values) {
        this.setMessage(message, values);
    }

    protected FSException(Throwable throwable, String message, Object... value) {
        super(throwable);
        this.setMessage(message, value);
    }

    public FSException(Class <?> clazz, String stringCode, String message) {
        this.clazz = clazz;
        this.stringCode = stringCode;
        this.message = message;
    }

    public FSException(Class <?> clazz, FSExceptionCode code, Object... values) {
        this(clazz);
        this.code = code;
        if (code != null) {
            this.setMessage(code.getDescription(), values);
        }
    }

    public FSException(Class <?> clazz, Throwable throwable, FSExceptionCode code, Object... values) {
        super(throwable);
        this.clazz = clazz;
        this.code = code;
        if (code != null) {
            this.setMessage(code.getDescription(), values);
        }
        this.throwable = throwable;
    }

    public FSException(Class <?> clazz, String message, Object... values) {
        super(String.format("ErrMsg: %s", message));
        this.clazz = clazz;
        this.message = message;
    }

    public FSException(Class <?> clazz, Throwable throwable) {
        super(throwable);
        this.throwable = throwable;
    }

    public FSException(Class <?> clazz, Throwable throwable, String message, Object... values) {
        super(String.format("ErrMsg: %s", message), throwable);
        this.clazz = clazz;
        this.setMessage(message, values);
        this.throwable = throwable;
    }

    public String getCode() {

        String finalCode = "";

        if (null != code) {
            finalCode = code.getValue();
        } else {
            finalCode = this.stringCode;
        }
        return finalCode;
    }

    @Override
    public String getMessage() {
        if (StringUtils.isNotEmpty(message)) {
            return message;
        }
        return code != null ? code.getDescription() : null;
    }

    public Class <?> getClazz() {
        return clazz;
    }

    public Throwable getThrowable() {
        return throwable;
    }

    protected void setMessage(String message, Object[] values) {
        if (values == null) {
            this.message = message;
        } else {
            if (!ArrayUtils.isEmpty(values)) {
                this.message = String.format(message, values);
            } else {
                this.message = message;
            }
        }
    }
}


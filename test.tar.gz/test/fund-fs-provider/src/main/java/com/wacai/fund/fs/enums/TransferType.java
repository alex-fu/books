package com.wacai.fund.fs.enums;

/**
 * TransferType enum
 *
 * @author mufu
 * @date 2017/10/26
 */
public enum TransferType {

    FTP(1, "FTP"), SFTP(2, "SFTP"), HTTP(3, "HTTP"), FOG(4, "FOG");

    private final Integer value;
    private final String type;

    private TransferType(Integer value, String type) {
        this.value = value;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static TransferType getInstance(Integer value) {
        for (TransferType channel : values()) {
            if (channel.value.equals(value)) {
                return channel;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

package com.wacai.fund.fs.process;


import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.service.enums.ConfirmType;

/**
 * AbstractProcessTemplate class
 * 抽象的处理模版类
 *
 * @author mufu
 * @date 2017/10/26
 */
public abstract class AbstractProcessTemplate {

    /**
     * process 处理包装方法
     * if(未完成且文件已存在){->下载 -> 处理 -> 上传} -> 消息
     *
     * @param task FsTransactionPo
     */
    public void process(FsTransactionPo task) throws Exception{
        //won't execute when you retry if has finish
    	//未上传完成探测文件是否已经存在
		if (!task.getFinishStatus() && detectionFile(task)) {
			download(task);
			parser(task);
			upload(task);
		}
		// if has success, not send again
		//当上传任务完成且回调结果不等于成功时才发送Kafka消息
		if (task.getFinishStatus() && !ConfirmType.SUCCESS.getValue().equals(task.getConfirmStatus())) {
			message(task);
		}
    }

    /**
     * detectionFile 探测文件
     * @param task:FsTransactionPo
     */
    public abstract boolean detectionFile(FsTransactionPo task)throws Exception;
    

    /**
     * download 下载
     * @param task:FsTransactionPo
     */
    public abstract void download(FsTransactionPo task)throws Exception;

    /**
     * parser 处理
     * @param task:FsTransactionPo
     */
    public abstract void parser(FsTransactionPo task);

    /**
     * upload 上传
     * @param task:FsTransactionPo
     */
    public abstract void upload(FsTransactionPo task)throws Exception;

    /**
     * message 消息
     * @param task:FsTransactionPo
     */
    public abstract void message(FsTransactionPo task)throws Exception;

}

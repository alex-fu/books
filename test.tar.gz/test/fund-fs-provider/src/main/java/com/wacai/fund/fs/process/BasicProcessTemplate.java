package com.wacai.fund.fs.process;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import com.wacai.fund.fs.client.*;
import com.wacai.fund.parent.client.constant.BasicConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.google.common.base.Splitter;
import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.fund.fs.bean.message.FSNotification;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.constant.TaConstant;
import com.wacai.fund.fs.enums.ChannelType;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.schedule.configuration.DynamicSchedule;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.utils.DateUtils;
import com.wacai.fund.fs.utils.FileUtils;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.client.enums.FileSysOutputTypeEnum;
import com.wacai.fund.parent.lang.utils.JacksonUtil;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;
import com.wacai.fund.parent.service.fileio.FileWriter;
import com.wacai.fund.parent.service.message.MessageService;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * BasicProcessTemplate
 *
 * @author mufu
 * @date 2017/10/27
 */
@Slf4j
public abstract class BasicProcessTemplate extends AbstractProcessTemplate {

	@Autowired
	MessageService messageService;

	@Autowired
	FsTransactionPoService fsTransactionPoService;

	@Autowired
	DynamicSchedule dynamicSchedule;

	@Autowired
	PropertyService propertyService;

	@Autowired
	FundTradeDayService fundTradeDayService;

	@Autowired
	FogTransfer fogTransfter;

	@Autowired
	SFTPTransfer sftpTransfter;

	@Autowired
	FTPTransfer ftpTransfer;

	@Autowired
	HuaAnSFTPTransfer huaAnSFTPTransfer;

	@Value("${fund.fs.topic}")
	private String fundFsTopic;

	@Override
	public void download(FsTransactionPo task) throws Exception {
		if (task.getDownloadStatus()) {
			// fetch file from task, split with comma
			List<String> lists = Splitter.on(",").splitToList(task.getDownloadFilePattern());
			log.info("download : downloadFilePattern == {}", task.getDownloadFilePattern());
			StringBuilder message = new StringBuilder();
			// download as lists
			lists.forEach(file -> {
				try {
					byte[] data = downloadTransfer(task).download(task.getProviderPath(), file);
					log.info("download the file =={}", file);
					//当文件为空时
					if (data == null || data.length == 0) {
						data = new byte[0];
						log.info("download the file {} is null ", file);
					}
					Path path = Paths.get(getCurrentDirectory(), file);
					if (!path.getParent().toFile().exists()) {
						FileUtils.createDirectory(path.getParent());
					}
					/* 2、将文件写入本地 */
					String filePath = getCurrentDirectory() + File.separator + file;
					// 如果文件已存在，删除原有的文件,然后再创建文件
                    File localFile = new File(filePath);
                    if (localFile.exists() && !localFile.delete()) {
                        log.error("filePath {} has already existed, but the delete failed ", file);
                    }
					FileWriter.build(filePath, data).writeBytesToFile().destory();
					//Files.write(path, data, StandardOpenOption.CREATE);
					log.info("download the file {}-{} successful!!!", task.getTaskId(), file);
				} catch (Exception e) {
					log.error("task {} download the file failed!!!", task.getTaskId(), e);
					message.append(file).append("文件下载失败");
					doFileProcessMoitor(task.getFileType(), task.getFileType() + "_download", ResultEnum.FAILED.getCode(), message.toString());
				}
			});
		} else {
			log.info("task {}-{} no dwnload requirement!!!", task.getTaskId(), task.getTaskName());
		}
	}

	@Override
	public void upload(FsTransactionPo task) throws Exception {
		if (task.getUploadStatus()) {
			try {
				log.info("upload : currentDirectory =={}; uploadFilePattern =={}", getCurrentDirectory(), task.getUploadFilePattern());
				Path path = Paths.get(getCurrentDirectory(), task.getUploadFilePattern());
				uploadTransfer(task).upload(task.getReceiverPath(), path.toString());
				log.info("task {}-{}  upload successful!!!", task.getTaskId(), task.getTaskName());
				// if finish the download-parser-upload process set the transaction
				// as true
				task.setFinishStatus(true);
				//ftp上传文件直接将回调确认设置为完成
				if (task.getReceiver().equals(ChannelType.JZ.getValue())
                        || task.getReceiver().equals(ChannelType.HA.getValue())) {
					task.setConfirmStatus(ConfirmType.SUCCESS.getValue());
				}
				fsTransactionPoService.update(task);
				//ftp上传文件直接将回调确认设置为完成
				if (task.getReceiver().equals(ChannelType.JZ.getValue())
                        || task.getReceiver().equals(ChannelType.HA.getValue())) {
					doFileProcessMoitor(task.getFileType(), task.getFileType()+"_upload", ResultEnum.SUCC.getCode(), "上传成功");
				}
			} catch (Exception e) {
				log.error("task {} download the file failed!!!", task.getTaskId(), e);
				doFileProcessMoitor(task.getFileType(), task.getFileType()+"_upload", ResultEnum.FAILED.getCode(), "上传失败");
			}
		} else {
			log.info("task {}-{} no upload requirement!!!", task.getTaskId(), task.getTaskName());
		}
	}

	@Override
	public void message(FsTransactionPo task) throws Exception {
		if (task.getReceiver().equals(ChannelType.FOG.getValue())) {
			FSNotification fsNotification = build(task);
			String message = JacksonUtil.objToJson(fsNotification);
			log.info(message);
			try {
				messageService.sendMessage(fundFsTopic, message);
				doFileProcessMoitor(task.getFileType(), task.getFileType() + "_message", ResultEnum.SUCC.getCode(),
						"消息通知成功");
			} catch (Exception e) {
				doFileProcessMoitor(task.getFileType(), task.getFileType() + "_message", ResultEnum.FAILED.getCode(),
						"消息通知失败");
				log.error("taskid= {} send message  failed!!!", task.getTaskId(), e);
			}
			task.setMessage(message);
			//if not lock,can execute, otherwise not execute
			if(!task.getLockStatus()){
				dynamicSchedule.setCron(DateUtils.getCronWithDelays(task.getWaitAckTime()));
				dynamicSchedule.setRunnable(() -> {
					FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(task.getTaskId());
					Optional<FsTransactionPo> fsTransactionPo1 = Optional.ofNullable(fsTransactionPo);
					if (fsTransactionPo1.isPresent()) {
						ConfirmType confirmType = ConfirmType.getInstance(fsTransactionPo.getConfirmStatus());
						if (ConfirmType.FAILED.getValue().equals(confirmType.getValue())) {
							log.info("taskid= {} 任务回调失败", task.getTaskId());
							doFileProcessMoitor(task.getFileType(), task.getFileType()+"_callback", ResultEnum.FAILED.getCode(), "任务回调失败");
							fsTransactionPo.setAlertStatus(true);
						} else if (ConfirmType.UNCONFIRMED.getValue().equals(confirmType.getValue())) {
							// timeout alert
							log.info("taskid= {} 任务回调超时", task.getTaskId());
							doFileProcessMoitor(task.getFileType(), task.getFileType()+"_callback", ResultEnum.FAILED.getCode(), "任务回调超时");
							fsTransactionPo.setAlertStatus(true);
						} else if (ConfirmType.SUCCESS.getValue().equals(confirmType.getValue())) {
							// if success , record
							log.info("the transaction has been handle by business taskId= {}", task.getTaskId());
						} else if (ConfirmType.RETRY.getValue().equals(confirmType.getValue())) {
							log.info("the transaction need retry taskId= {}", task.getTaskId());
						}
						fsTransactionPo.setLockStatus(false);// unlock when execute
						// schedule task
						fsTransactionPoService.update(fsTransactionPo);
					}
				});
				task.setLockStatus(true);// lock when start schedule job
			}
			fsTransactionPoService.update(task);
		}

	}
	
	@Override
	public boolean detectionFile(FsTransactionPo task)throws Exception{
		boolean flag = true;
		List<String> lists = Splitter.on(",").splitToList(task.getDownloadFilePattern());
		log.info("detectionFile : downloadFilePattern == {}", task.getDownloadFilePattern());
		try {
			for (String fileName : lists) {
				downloadTransfer(task).download(task.getProviderPath(), fileName);
				log.info("detectionFile : taskId =={}; fileName =={}", task.getTaskId(), fileName);
			}
			doFileProcessMoitor(task.getFileType(), task.getFileType()+"_detection", ResultEnum.SUCC.getCode(), "探测成功");
		} catch (Exception e) {
			flag = false;
			log.error("detectionFile failed!", e);
		}
		return flag;
	}
	
	/**
	 * doFileProcessMoitor:文件系统任务处理监控
	 * @param fileType
	 * @param actionCode
	 * @param result
	 * @param message
	 * @author qingniu
	 * @date 2018年1月10日 下午3:23:32
	 */
	private void doFileProcessMoitor(Integer fileType, String actionCode, String result, String message) {
		String mtrace = "";
		String msg = "";
		String action = TaConstant.getMonitorActionMap().get(actionCode);
		// 账户确认文件
		if (Integer.valueOf(FileSysOutputTypeEnum.ACC_ACK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_02_TASK.getCode();
			msg = MtraceEnum.FS_02_TASK.getDesc() + message;
			// 交易申请文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TRA_APP.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_03_TASK.getCode();
			msg = MtraceEnum.FS_03_TASK.getDesc() + message;
			// 交易确认文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TRA_ACK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_04_06_TASK.getCode();
			msg = MtraceEnum.FS_04_06_TASK.getDesc() + message;
			// 份额确认文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.VOL_CHK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_05_TASK.getCode();
			msg = MtraceEnum.FS_05_TASK.getDesc() + message;
			// 基金行情文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TA_07.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_07_TASK.getCode();
			msg = MtraceEnum.FS_07_TASK.getDesc() + message;
		} else if (Integer.valueOf(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_EXPORT.getCode()).equals(fileType)) {
            //华安份额划转文件
		    mtrace = MtraceEnum.FS_08_TASK.getCode();
            msg = MtraceEnum.FS_08_TASK.getDesc() + message;
        } else if (Integer.valueOf(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode()).equals(fileType)) {
            //华安份额划转结果文件
		    mtrace = MtraceEnum.FS_09_TASK.getCode();
            msg = MtraceEnum.FS_09_TASK.getDesc() + message;
        }
		log.info("mtrace =={};action =={};result =={};message =={};", mtrace, action, result, msg);
		if (StringUtils.isNotBlank(mtrace)) {
			BizMonitor.report(new MInfo(mtrace, action, result, msg));
		}
	}

	private FSNotification build(FsTransactionPo task) {
		FSNotification fsNotification = new FSNotification();
		fsNotification.setTaskId(task.getTaskId());
		fsNotification.setFileName(task.getUploadFilePattern());
		fsNotification.setFileGroup("fund");
		fsNotification.setFileType(task.getFileType());
		parseFromFileName(fsNotification, task.getDownloadFilePattern());
		return fsNotification;
	}

	private void parseFromFileName(FSNotification fsNotification, String fileName) {
	    if(new Integer(FileSysOutputTypeEnum.HJB_BAL_TRANSFER_IMPORT.getCode()).equals(fsNotification.getFileType())) {
            String[] values = fileName.split("_", -1);
            fsNotification.setTaCode(values[values.length - 2]);
            fsNotification.setTradeDate(values[values.length - 1].substring(0, 8));
        } else {
            String[] values = fileName.split(",")[0].split("_");
            fsNotification.setTaCode(values[1]);
            fsNotification.setTradeDate(values[3].substring(0, 8));
        }
	}

	/**
	 * getCurrentDirectory:获取本地文件目录
	 * @return
	 * @author qingniu
	 * @date 2017年12月19日 下午8:54:55
	 */
	public String getCurrentDirectory() {
		String currentDirectory = "";
		try {
			String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
			if (StringUtils.isNotBlank(tradeDate)) {
				currentDirectory = propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH, "/data/program/download")
						+ File.separator + tradeDate;
			}
			log.info("getCurrentDirectory : tradeDate =={}; currentDirectory  == {}", tradeDate, currentDirectory);
		} catch (Exception e) {
			log.error("getCurrentDirectory happen Exception", e);
		}
		return  currentDirectory;
	}

	public Transfer downloadTransfer(FsTransactionPo task) {
		ChannelType channelType = ChannelType.getInstance(task.getProvider());
		return getTransfer(channelType);
	}

	public Transfer uploadTransfer(FsTransactionPo task) {
		ChannelType channelType = ChannelType.getInstance(task.getReceiver());
		return getTransfer(channelType);
	}

	private Transfer getTransfer(ChannelType channelType) {
		try {
			Transfer transfer = channelType.getTransfer().newInstance();
			log.info(transfer.getClass().toString());
			if (transfer.getClass().isAssignableFrom(fogTransfter.getClass())) {
				transfer = fogTransfter;
			} else if (transfer.getClass().isAssignableFrom(sftpTransfter.getClass())) {
				transfer = sftpTransfter;
			} else if (transfer.getClass().isAssignableFrom(ftpTransfer.getClass())) {
				transfer = ftpTransfer;
			} else if(transfer.getClass().isAssignableFrom(huaAnSFTPTransfer.getClass())) {
                transfer = huaAnSFTPTransfer;
            }
			return transfer;
		} catch (InstantiationException | IllegalAccessException e) {
			log.error("get transfer failed", e);
		}
		return null;
	}

	public abstract TaskType getType();
}

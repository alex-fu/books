package com.wacai.fund.fs.process;

import java.util.EnumMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.enums.TaskType;

/**
 * BasicProcessTemplateFactory
 *
 * @author mufu
 * @date 2017/11/29
 */
@Service("basicProcessTemplateFactory")
public class BasicProcessTemplateFactory implements ApplicationContextAware {
    private static Map <TaskType, BasicProcessTemplate> processTemplateMap ;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        Map <String, BasicProcessTemplate> map = applicationContext.getBeansOfType(BasicProcessTemplate.class);
        processTemplateMap = new EnumMap<>(TaskType.class);
        map.forEach((key, value) -> processTemplateMap.put(value.getType(), value));
    }

    public static <T extends BasicProcessTemplate> T getProcessTemplate(TaskType taskType) {
        return (T) processTemplateMap.get(taskType);
    }
}

package com.wacai.fund.fs.service.ta.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.ImmutableList;
import com.wacai.fund.account.api.FundCustInfoService;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.TradeConfirm;
import com.wacai.fund.fs.bean.ta.Model04;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.service.ta.SxbFundFilterService;
import com.wacai.fund.fs.service.ta.TradeConfirmService;
import com.wacai.fund.fs.utils.ConvertUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * TradeConfirmService04Impl
 *
 * @author mufu
 * @date 2017/11/17
 */
@Slf4j
@Service
public class TradeConfirmService04Impl implements TradeConfirmService {
    private static final List <String> CODES = ImmutableList.of("120", "122", "139");

    @Autowired
    FundCustInfoService fundCustInfoService;
    
    @Autowired
	private SxbFundFilterService sxbFundFilterService;
    
    @Override
    public List <TradeConfirm> convert(TABeans <TA> ta) {
        List <TradeConfirm> tcs = new ArrayList <>();
        List <TA> m04s = ta.getTas();
        List <String> sxbFundList = sxbFundFilterService.getSxbFundList();
        for (TA t : m04s) {
            TradeConfirm tc = new TradeConfirm();
            Model04 m04 = (Model04) t;
            if("1".equals(m04.getDetailFlag())){
                continue;
            }
            // 过滤不属于生息宝基金的数据
			if (!CollectionUtils.isEmpty(sxbFundList) && !sxbFundList.contains(m04.getFundCode())) {
				log.info("TradeConfirmService04Impl.convert : fundCode == {} does not belong to sxb",
						m04.getFundCode());
				continue;
			}
            tc.setUid(fetchUID(fundCustInfoService, m04.getTransactionAccountID()));
            tc.setTradeAccount(m04.getTransactionAccountID());
            tc.setFundAccount(m04.getTAAccountID());
            tc.setTradeNo(m04.getAppSheetSerialNo());
            tc.setAckNo(m04.getTASerialNO());
            tc.setBusiCode(m04.getBusinessCode());
            tc.setFundCode(m04.getFundCode());
            tc.setTaCode(ta.getTa());
            tc.setAckDate(m04.getTransactionCfmDate());
            if (CODES.contains(m04.getBusinessCode())) {
                tc.setAckAmt(Long.valueOf(ConvertUtils.convertToCent(m04.getConfirmedAmount())));
            } else {
                tc.setAckAmt(Long.valueOf(ConvertUtils.convertToCent(m04.getConfirmedVol())));
            }
            tc.setRetCode(m04.getReturnCode());
            tc.setRetMsg(m04.getSpecification());
            tcs.add(tc);
        }
        return tcs;
    }

}

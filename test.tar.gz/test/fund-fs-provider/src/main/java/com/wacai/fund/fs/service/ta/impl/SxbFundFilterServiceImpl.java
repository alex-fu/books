/**
 *Copyright (c) 2017, ShangHai WACAI INTERNET FINANCIAL SERVICES Co., Ltd.
 *All right reserved.
 *
 *THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF WACAI INTERNET FINANCIAL SERVICES
 *MANAGEMENT CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT BE DISCLOSED
 *TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART,
 *WITHOUT THE PRIOR WRITTEN PERMISSION OF WACAI INTERNET FINANCIAL SERVICES
 * CO., LTD.
*/


package com.wacai.fund.fs.service.ta.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.service.ta.SxbFundFilterService;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * @description: 获取生息宝基金列表
 * @author qingniu
 * @date 2017年12月11日 下午3:57:30
 * @since JDK 1.8
 */
@Slf4j
@Service("sxbFundFilterService")
public class SxbFundFilterServiceImpl implements SxbFundFilterService {

    @Autowired
	PropertyService propertyService;
	
	@Override
	public List<String> getSxbFundList() {
		List <String> sxbFundList = new ArrayList<>();
    	String sxbFundListStr = propertyService.getString(PropertyConstant.FUND.FUND_FILTER_SXB_LIST);
    	log.info("SxbFundFilterService.getSxbFundList : sxbFundListStr == {}" , sxbFundListStr);
    	if (StringUtils.isNotBlank(sxbFundListStr)) {
    		sxbFundList = Arrays.asList(sxbFundListStr.split(","));
		}
    	return sxbFundList;
	}

}


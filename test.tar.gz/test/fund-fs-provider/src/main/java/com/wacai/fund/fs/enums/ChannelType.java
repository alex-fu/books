package com.wacai.fund.fs.enums;

import com.wacai.fund.fs.client.FTPTransfer;
import com.wacai.fund.fs.client.FogTransfer;
import com.wacai.fund.fs.client.HuaAnSFTPTransfer;
import com.wacai.fund.fs.client.Transfer;

/**
 *  ChannelType enum
 *  provider and receiver value
 *
 *  @author mufu
 *  @date 2017/11/1
 */
public enum ChannelType {

    /**
     * 和自研基金系统的交互渠道
     */
    FS(1, "fund文件系统", null),
    /**
     * 内部交互的所有文件均经过fog文件系统
     */
    FOG(2, "fog系统", FogTransfer.class),
    /**
     * 和金证系统交互的FTP目录
     */
    JZ(3, "金证", FTPTransfer.class),
    /**
     * 深证通下载的目录window机器，提供给的FTP目录
     */
    SZT(4, "深证通", FTPTransfer.class),
    /**
     * 华夏直销TA的交易渠道，非华夏代销TA
     */
    HX(5, "华夏", null),

    /**
     * 华安直销TA的交易渠道，非华安代销TA
     */
    HA(6, "华安", HuaAnSFTPTransfer.class);

    private final Integer value;
    private final String type;
    private final Class <? extends Transfer> transfer;

    private ChannelType(Integer value, String type, Class <? extends Transfer> transfer) {
        this.value = value;
        this.type = type;
        this.transfer = transfer;
    }

    public Integer getValue() { return value;}

    public String getType() {
        return type;
    }

    public  Class <? extends Transfer> getTransfer(){return transfer;}

    public static ChannelType getInstance(Integer value) {
        for (ChannelType channel : values()) {
            if (channel.value.equals(value)) {
                return channel;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

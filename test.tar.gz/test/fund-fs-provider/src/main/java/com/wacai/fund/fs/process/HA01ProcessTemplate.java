package com.wacai.fund.fs.process;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author jingfan
 * @description: 华安份额划转导出文件处理模板
 * @date 2018/2/6 下午5:04
 * @since JDK 1.8
 */
@Slf4j
@Service("hA01ProcessTemplate")
public class HA01ProcessTemplate extends BasicProcessTemplate {

    @Override
    public TaskType getType() {
        return TaskType.TASK_9;
    }

    @Override
    public void parser(FsTransactionPo task) {
        //份额划转导出文件暂不做处理原样输出
    }
}

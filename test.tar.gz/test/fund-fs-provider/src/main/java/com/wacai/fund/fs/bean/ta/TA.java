package com.wacai.fund.fs.bean.ta;

public interface TA {
}

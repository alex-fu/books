package com.wacai.fund.fs.mapper;


import com.wacai.fund.fs.bean.task.FsTemplatePo;

import java.util.List;

/**
 * 任务模板表的Mapper类
 * Table: fs_template - 任务模板表
 * 
 * @since 2017-11-23 08:24:44
 */
public interface FsTemplateMapper {

	/** 新增任务模板信息 */
	int insert(FsTemplatePo fsTemplatePo);
	
	/** 更新任务模板信息 */
	int update(FsTemplatePo fsTemplatePo);
	
	/** 根据主键查询任务模板信息 */
	FsTemplatePo selectByPrimaryKey(Long id);

	/** 查询所有的有效的任务模板信息 **/
	List<FsTemplatePo> selectAllTemplate();
	
}

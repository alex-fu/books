package com.wacai.fund.fs.main;

import com.wacai.fund.parent.monitor.BizMonitor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Bootstrap
 *
 * @author mufu
 * @date 2017/10/11
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
@EnableScheduling
public class Bootstrap {

    public static void main(String[] args) {
        try {
            BizMonitor.appName = "fund-fs-mgmt";
            SpringApplication application = new SpringApplication(Bootstrap.class,
                    "classpath*:META-INF/spring/spring-context.xml");
            application.run(args);
        } catch (Exception e) {
            System.exit(0);
        }
    }
}

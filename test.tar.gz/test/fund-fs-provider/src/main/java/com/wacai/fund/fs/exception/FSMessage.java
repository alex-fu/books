package com.wacai.fund.fs.exception;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;

/**
 * FSNotification class
 *
 * @author mufu
 * @date 2017/11/06
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
public class FSMessage implements Serializable {

    private static final long serialVersionUID = -404008917840365692L;

    private @NonNull
    MessageLevel messageLevel;

    private @NonNull
    String messageType;

    private @NonNull
    String message;

    private Throwable throwable;

}

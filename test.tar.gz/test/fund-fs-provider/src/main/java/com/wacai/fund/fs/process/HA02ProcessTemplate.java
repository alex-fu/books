package com.wacai.fund.fs.process;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.constant.SystemConstant;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.parent.client.constant.BasicConstant;
import com.wacai.fund.parent.client.exception.FundParentException;
import com.wacai.fund.parent.service.fileio.FileWriter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.Charset;

/**
 * @author jingfan
 * @description: 华安份额划转结果文件处理模板
 * @date 2018/2/6 下午4:06
 * @since JDK 1.8
 */
@Slf4j
@Service("hA02ProcessTemplate")
public class HA02ProcessTemplate extends BasicProcessTemplate  {

    @Override
    public TaskType getType() {
        return TaskType.TASK_10;
    }

    @Override
    public void parser(FsTransactionPo task) {
        try {
            String fileName = task.getDownloadFilePattern();
            String path = getCurrentDirectory();
            File readerFile = new File(path, fileName + ".bak");
            File file = new File(path, fileName);
            //对下载的文件先做重命名
            file.renameTo(readerFile);
            //读写文件 & 校验文件内容
            readAndWriterFile(readerFile, file);
        } catch (Exception e) {
            log.error("huaan file parse error, e = ", e);
            throw FundParentException.wrap(e.getMessage());
        }
    }

    /**
     * 读写文件 & 校验文件内容
     * @param readerFile
     * @param file
     * @throws Exception
     */
    private void readAndWriterFile(File readerFile, File file) throws Exception {
        BufferedReader reader = null;
        FileWriter fileWriter = null;
        try {
            fileWriter = FileWriter.build(file, SystemConstant.DEFAULT_BUFFERSIZE);
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(readerFile), Charset.forName("GBK")));
            String line = null;
            Integer count = 0, totalCount = 0;
            BigDecimal totalVol = BigDecimal.ZERO, headerVol = BigDecimal.ZERO;
            while ((line = reader.readLine()) != null) {
                if(StringUtils.isBlank(line)) {
                    continue;
                }
                count ++;
                log.info("line = {}", line);
                String[] data = line.split(BasicConstant.FILE.READFILE_VERTICAL_BAR_SEPARATOR, -1);
                //第一行是头信息 文件名|总笔数|总确认份额
                if(count == 1) {
                    String headerFileName = data[0];
                    if(!headerFileName.equals(file.getName())) {
                        throw FundParentException.wrap("Head file name is incompatible");
                    }
                    //总笔数
                    totalCount = Integer.valueOf(data[1]);
                    //总确认份额
                    headerVol = new BigDecimal(data[2]);
                    continue;
                }
                if (data.length != 14) {
                    throw FundParentException.wrap("file content formatting error").set("length", data.length).set("line", line);
                }
                BigDecimal confirmVol = new BigDecimal(data[7]);//确认份额
                totalVol = totalVol.add(confirmVol);
                fileWriter.write(line);
                fileWriter.newLine();
            }
            //校验头部的总记录和文件内容总记录
            if (totalCount != (count - 1)) {
                throw FundParentException.wrap("file header count is incompatible")
                        .set("headerCt", totalCount).set("contentCt", count - 1);
            }
            //校验头部的总份额和文件内容总份额
            if(totalVol.compareTo(headerVol) != 0) {
                throw FundParentException.wrap("file header totalVol is incompatible")
                        .set("headerVol", headerVol).set("contentVol", totalVol);
            }
        } catch (Exception e) {
            log.error("reder file & writer file error, e = ", e);
            throw FundParentException.wrap(e.getMessage());
        } finally {
            if(reader != null)
                reader.close();
            if(fileWriter != null)
                fileWriter.destory();
        }
    }
}

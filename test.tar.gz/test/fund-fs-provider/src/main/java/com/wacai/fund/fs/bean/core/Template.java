package com.wacai.fund.fs.bean.core;

import java.util.List;

import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.utils.TemplateUtils;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


/**
 * Template class
 *
 * @author mufu
 * @date 2017/10/31
 */
@Data
@Slf4j
public class Template {

    private TAType type;
    private List <Field> fields;

    public Template(TAType type) {
        this.type = type;
        this.fields = TemplateUtils.loadTemplate(type);
    }

    public int getLength() {
        int length = 0;
        for (Field field : getFields()) {
            length = length + field.getLength();
        }
        log.info("Template.getLength : length =={}", length);
        return length;
    }
}

package com.wacai.fund.fs.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * FSExceptionCode enum
 *
 * @author mufu
 * @date 2017/11/06
 */
public enum FSExceptionCode {

    CODE_0000("0000", "Unknow Exception"),
    CODE_0001("0001", "Download Exception"),
    CODE_0002("0002", "upload Exception"),
    CODE_0003("0003", "parser Exception"),
    CODE_0004("0004", "no task templates");

    public final String value;
    public final String description;

    private FSExceptionCode(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public static FSExceptionCode getInstance(String value) {
        for (FSExceptionCode code : values()) {
            if (code.value == value) {
                return code;
            }
        }

        return null;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}

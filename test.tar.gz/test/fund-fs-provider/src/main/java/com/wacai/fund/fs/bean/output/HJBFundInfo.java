package com.wacai.fund.fs.bean.output;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * HJBFundInfo
 *
 * @author mufu
 * @date 2018/01/22
 */
@Data
public class HJBFundInfo implements Serializable {

    private static final long serialVersionUID = -2850014442666418270L;

    private String fundCode;
    private String fundName;
    private String quoDate;
    private BigDecimal valueLine;
    private BigDecimal tradingPrice;
    private BigDecimal netVal;
    private String fundStatus;
    private BigDecimal minBidsAmountByIndi;
    private BigDecimal minAppBidsAmountByIndi;
    private BigDecimal minRedemptionVol;
    private BigDecimal indiMaxPurchase;
    private BigDecimal indiDayMaxSumBuy;
    private BigDecimal indiDayMaxSumRedeem;
    private BigDecimal indiMaxRedeem;
    private BigDecimal minAccountBalance;

    @Override
    public String toString() {
        List <Object> list = Lists.newArrayList(this.fundCode, this.fundName, this.quoDate, this.valueLine, this.tradingPrice,
                this.netVal, this.fundStatus, this.minBidsAmountByIndi, this.minAppBidsAmountByIndi, this.minRedemptionVol, this.indiMaxPurchase, this.indiDayMaxSumBuy,
                this.indiDayMaxSumRedeem, this.indiMaxRedeem, this.minAccountBalance);
        return Joiner.on("|").useForNull("").join(list);
    }

}

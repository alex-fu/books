package com.wacai.fund.fs.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.constant.SystemConstant;

/**
 * FileUtils
 *
 * @author mufu
 * @date 2017/11/08
 */
public class FileUtils {
    private static final Logger logger = LoggerFactory.getLogger(TABeans.class);

    public static final String GBK_ENCODING = SystemConstant.GBK_ENCODING;
    public static final String DEFAULT_ENCODING = SystemConstant.LATIN_ENCODING;
    public static final String DEFAULT_LINE_SEPARATOR = SystemConstant.WINDOW_LINE_SEPARATOR;
    public static final Charset DEFAULT_CHARSET = StandardCharsets.ISO_8859_1;

    private FileUtils() {
	}

    public static List <String> readFromFile(Path path, Charset charset, String origin, String encoding) {
        List <String> lines = new ArrayList <>();
        try (BufferedReader br = Files.newBufferedReader(path,
                charset)) {
            String line = null;
            while ((line = br.readLine()) != null) {
                line = new String(line.getBytes(origin), encoding);
                lines.add(line);
                logger.info("line[" + line + "]");
            }
        } catch (Exception e) {
            logger.error("read failed!!!, reason: {}", e);
        }
        return lines;
    }

    public static List <String> readFromFile(Path path) {
        return readFromFile(path, DEFAULT_CHARSET, DEFAULT_ENCODING, GBK_ENCODING);
    }

    interface IOConsumer<T> {
        void accept(T t) throws IOException;
    }

    private static <T> Consumer <T> wrap(IOConsumer <? super T> ioc) {
        return t -> {
            try {
                ioc.accept(t);
            } catch (IOException ioe) {
                throw new UncheckedIOException(ioe);
            }
        };
    }

    public static void writeToFile(List <String> lines, Path path, Charset encoding, String lineSeparator) {
        try (BufferedWriter bw = Files.newBufferedWriter(path, encoding)) {
            lines.stream().forEach(wrap(o -> bw.write(o + lineSeparator)));
        } catch (IOException e) {
            logger.error("write to file failed, {}", e);
        }
    }

    public static void writeToFile(List <String> lines, Path path) {
        try (BufferedWriter bw = Files.newBufferedWriter(path)) {
            lines.stream().forEach(wrap(o -> bw.write(o+DEFAULT_LINE_SEPARATOR)));
        } catch (IOException e) {
            logger.error("write to file failed, {}", e);
        }
    }

    public static FileAttribute<Set <PosixFilePermission>> getFileAttributes(String pattern){
        Set<PosixFilePermission> perms = PosixFilePermissions
                .fromString(pattern);
        return PosixFilePermissions.asFileAttribute(perms);
    }

    public static FileAttribute<Set <PosixFilePermission>> getDefaultFileAttributes(){
        return getFileAttributes("rwxrwxrwx");
    }

    /**
     * create directory in different os
     * @param path
     * @return
     * @throws IOException
     */
	public static Path createDirectory(Path path) throws IOException {
		String os = System.getProperty("os.name");
		if (StringUtils.isNotBlank(os) && os.contains("Windows")) {
			return Files.createDirectory(path);
		}
		return Files.createDirectory(path, getDefaultFileAttributes());
	}
}

package com.wacai.fund.fs.client;

import com.wacai.fund.parent.service.fog.FogFileUpDownService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * FogTransfter
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Service
public class FogTransfer implements Transfer {

    @Autowired
    FogFileUpDownService fogFileUpDownService;

    @Override
    public byte[] download(String folder, String fileName) {
        log.info("fog execute download from {}/{}", folder, fileName);
        return fogFileUpDownService.download(folder, fileName);
    }

    @Override
    public void upload(String folder, String fileName) {
        log.info("fog execute upload from {}/{}", folder, fileName);
        fogFileUpDownService.upload(fileName);
    }
}

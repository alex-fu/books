package com.wacai.fund.fs.bean.core;

import lombok.Data;

/**
 * Field class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Field {
	private String name;
	private String type;
	private Integer length;
	private Integer precision;
}
package com.wacai.fund.fs.service.builder;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.output.File03JZ;
import com.wacai.fund.fs.bean.ta.Model03JZ;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.enums.TAType;

import lombok.extern.slf4j.Slf4j;

/**
 * JZ03FileBuilder
 *
 * @author mufu
 * @date 2017/11/21
 */
@Slf4j
@Service("jz03FileBuilder")
public class JZ03FileBuilder extends AbstractFileBuilder {

    private static final Template TEMPLATE = new Template(TAType.TA_03JZ);

    private static final TAParser TA_PARSER = TAParser.getInstance();

    private TABeans <TA> tab;

    @Override
    protected void init(){
        tab = TA_PARSER.buildFromSXB(getSource(), TEMPLATE);
        log.info("AccountConfirm FileBuilder build init successful!!!");
    }

    @Override
    public List <String> fetch() {
        String ta = tab.getTa();
        String tradeDate = tab.getTradeDate();
        List<Model03JZ> datas = new ArrayList <>();
        tab.getTas().stream().forEach((e)->{
            datas.add((Model03JZ) e);
        });
        File03JZ file03JZ = new File03JZ(ta,tradeDate,datas);
        return file03JZ.transfer();
    }

    @Override
    public Path buildPath() {
        File file = new File(getSource());
        Path path = Paths.get(file.getParent(),getDist());
        return path;
    }
}

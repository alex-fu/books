package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.utils.ConvertUtils;

import lombok.Data;

/**
 * Model07git  class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model07 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7990011857731804531L;

	private String FundName;
	private BigDecimal TotalFundVol;
	private String FundCode;
	private String FundStatus;
	private BigDecimal NAV;
	private String UpdateDate;
	private String NetValueType;
	private BigDecimal AccumulativeNAV;
	private String ConvertStatus;
	private String PeriodicStatus;
	private String TransferAgencyStatus;
	private BigDecimal FundSize;
	private String CurrencyType;
	private String AnnouncFlag;
	private String DefDividendMethod;
	private BigDecimal InstAppSubsAmnt;
	private BigDecimal InstAppSubsVol;
	private BigDecimal MinAmountByInst;
	private BigDecimal MinVolByInst;
	private String CustodianCode;
	private BigDecimal AmountOfPeriodicSubs;
	private String DateOfPeriodicSubs;
	private BigDecimal MaxRedemptionVol;
	private BigDecimal MinAccountBalance;
	private String IPOStartDate;
	private String IPOEndDate;
	private String FundManagerCode;
	private BigDecimal IndiAppSubsVol;
	private BigDecimal IndiAppSubsAmount;
	private BigDecimal MinSubsVolByIndi;
	private BigDecimal MinSubsAmountByIndi;
	private String RegistrarCode;
	private String FundSponsor;
	private BigDecimal TradingPrice;
	private BigDecimal FaceValue;
	private String DividentDate;
	private String RegistrationDate;
	private String XRDate;
	private BigDecimal MaxSubsVolByIndi;
	private BigDecimal MaxSubsAmountByIndi;
	private BigDecimal MaxSubsVolByInst;
	private BigDecimal MaxSubsAmountByInst;
	private BigDecimal UnitSubsVolByIndi;
	private BigDecimal UnitSubsAmountByIndi;
	private BigDecimal UnitSubsVolByInst;
	private BigDecimal UnitSubsAmountByInst;
	private BigDecimal MinBidsAmountByIndi;
	private BigDecimal MinBidsAmountByInst;
	private BigDecimal MinAppBidsAmountByIndi;
	private BigDecimal MinAppBidsAmountByInst;
	private BigDecimal MinRedemptionVol;
	private BigDecimal MinInterconvertVol;
	private String IssueTypeByIndi;
	private String IssueTypeByInst;
	private String SubsType;
	private String CollectFeeType;
	private String NextTradeDate;
	private BigDecimal ValueLine;
	private BigDecimal TotalDivident;
	private BigDecimal FundIncome;
	private String FundIncomeFlag;
	private BigDecimal Yield;
	private String YieldFlag;
	private BigDecimal GuaranteedNAV;
	private BigDecimal FundYearIncomeRate;
	private String FundYearIncomeRateFlag;
	private BigDecimal IndiMaxPurchase;
	private BigDecimal InstMaxPurchase;
	private BigDecimal IndiDayMaxSumBuy;
	private BigDecimal InstDayMaxSumBuy;
	private BigDecimal IndiDayMaxSumRedeem;
	private BigDecimal InstDayMaxSumRedeem;
	private BigDecimal IndiMaxRedeem;
	private BigDecimal InstMaxRedeem;
	private String FundDayIncomeFlag;
	private BigDecimal FundDayIncome;
	private String AllowBreachRedempt;
	private String FundType;
	private String FundTypeName;
	private String RegistrarName;
	private String FundManagerName;
	private String FundServerTel;
	private String FundInternetAddress;

	@Override
	public String toString(){
		List <Object> list = Lists.newArrayList(ConvertUtils.sortAsField(this,new Template((TAType.TA_07))).values());
		return Joiner.on("|").useForNull("").join(list);
	}

}

package com.wacai.fund.fs.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.client.exception.FundParentException;
import com.wacai.fund.parent.service.net.FtpClientService;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * FTPTransfer
 *
 * @author mufu
 * @date 2017/11/29
 */
@Slf4j
@Service
public class FTPTransfer implements Transfer {

    @Autowired
    FtpClientService ftpClientService;
    
    @Autowired
	private PropertyService propertyService;

    @Override
	public byte[] download(String folder, String fileName) {
		try {
			log.info("ftp execute download from {}/{}", folder, fileName);
			String server = propertyService.getString(PropertyConstant.FUND.SZT_FTP_HOST);
			int port = propertyService.getInt(PropertyConstant.FUND.SZT_FTP_PORT);
			String userName = propertyService.getString(PropertyConstant.FUND.SZT_FTP_USERNAME);
			String password = propertyService.getString(PropertyConstant.FUND.SZT_FTP_PASSWORD);
			log.info("server=={};port=={}", server, port);
			boolean isLogin = ftpClientService.connect(server, port, userName, password);
			log.info("ftp execute download isLogin={}", isLogin);
			if (isLogin) {
				return ftpClientService.download(folder, fileName);
			} else {
				throw FundParentException.wrap("ftp login failed");
			}
		} catch (Exception e) {
			log.error("ftp execute download failed", e);
			throw FundParentException.wrap("ftp download failed");
		}
	}

	@Override
	public void upload(String folder, String fileName) throws Exception {
		try {
			log.info("ftp execute upload to {}/{}", folder, fileName);
			String server = propertyService.getString(PropertyConstant.FUND.SZT_FTP_HOST);
			int port = propertyService.getInt(PropertyConstant.FUND.SZT_FTP_PORT);
			String userName = propertyService.getString(PropertyConstant.FUND.SZT_FTP_USERNAME);
			String password = propertyService.getString(PropertyConstant.FUND.SZT_FTP_PASSWORD);
			boolean isLogin = ftpClientService.connect(server, port, userName, password);
			log.info("ftp execute upload isLogin={}", isLogin);
			if (isLogin) {
				ftpClientService.upload(folder, fileName);
			} else {
				throw FundParentException.wrap("ftp login failed");
			}
		} catch (Exception e) {
			log.error("ftp execute upload failed", e);
			throw FundParentException.wrap("ftp upload failed");
		}
    }
}

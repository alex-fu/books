package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;

import lombok.Data;

/**
 * Model02 class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model02 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2038066262172966361L;

	private String AppSheetSerialNo;
	private String TransactionCfmDate;
	private String ReturnCode;
	private String TransactionAccountID;
	private String DistributorCode;
	private String BusinessCode;
	private String TAAccountID;
	private String MultiAcctFlag;
	private String TASerialNO;
	private String TransactionDate;
	private String TransactionTime;
	private String BranchCode;
	private String FromTAflag;
	private String CertificateType;
	private String CertificateNo;
	private String InvestorName;
	private String IndividualOrInstitution;
	private String AccountAbbr;
	private String AccountCardID;
	private String RegionCode;
	private String TargetTransactionAccountID;
	private String NetNo;
	private String Specification;
	private String CustomerNo;
	private String FrozenCause;
	private String FreezingDeadline;
	private String ErrorDetail;
}
package com.wacai.fund.fs.service.api;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.mapper.FsTransactionMapper;
import com.wacai.fund.fs.process.BasicProcessTemplateFactory;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.parent.client.result.Result;

import lombok.extern.slf4j.Slf4j;

/**
 * FileTaskServiceImpl
 *
 * @author mufu
 * @date 2017/11/28
 */
@Slf4j
@Service("fileTaskService")
public class FileTaskServiceImpl implements FileTaskService {

    @Autowired
    FsTransactionMapper fsTransactionMapper;

    @Autowired
    BasicProcessTemplateFactory basicProcessTemplateFactory;

    @Override
    public Result <Boolean> doFileTask(String taskId) {
        Result <Boolean> result = new Result <>();
        if (StringUtils.isEmpty(taskId)) {
            result.setValue(false);
            result.setError("please provide taskId!!!");
            return result;
        }
        FsTransactionPo fsTransactionPo = fsTransactionMapper.selectByTaskId(taskId);
        Optional <FsTransactionPo> optional = Optional.ofNullable(fsTransactionPo);
        if (optional.isPresent()) {
            fsTransactionPo.setFinishStatus(false);
            fsTransactionPo.setConfirmStatus(ConfirmType.UNCONFIRMED.getValue());
            try {
                execute(fsTransactionPo);
                result.setValue(true);
            } catch (Exception e) {
                log.error("invoke method failed, reason {}", e);
            }
        } else {
            result.setValue(false);
            result.setError("TaskId not found!!!");
            return result;
        }
        return result;
    }

    @Async
    public void execute(FsTransactionPo fsTransactionPo) throws Exception {
        Optional <FsTransactionPo> fsTransactionPoOptional = Optional.of(fsTransactionPo);
        if (fsTransactionPoOptional.isPresent()) {
            String taskId = fsTransactionPoOptional.map(FsTransactionPo::getTaskId).filter(id -> id.length() > 8).orElseThrow(NoSuchElementException::new);
            log.info("taskId = {}", taskId);
            BasicProcessTemplateFactory.getProcessTemplate(getFromTaskId(taskId)).process(fsTransactionPo);
        }
    }

    private static TaskType getFromTaskId(String taskId) {
        Integer taskType = Integer.valueOf(taskId.substring(8, taskId.length()));
        return TaskType.getInstance(taskType);
    }
}

package com.wacai.fund.fs.service.ta.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.wacai.fund.account.api.FundCustInfoService;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.VolConfirm;
import com.wacai.fund.fs.bean.ta.Model05;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.service.ta.SxbFundFilterService;
import com.wacai.fund.fs.service.ta.VolumeConfirmService;
import com.wacai.fund.fs.utils.ConvertUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * VolConfirmServiceImpl
 *
 * @author mufu
 * @date 2017/11/17
 */
@Slf4j
@Service("volumeConfirmServiceImpl")
public class VolumeConfirmServiceImpl implements VolumeConfirmService {

    @Autowired
    FundCustInfoService fundCustInfoService;
    
    @Autowired
	private SxbFundFilterService sxbFundFilterService;

    @Override
    public List <VolConfirm> convert(TABeans<TA> ta) {
        List <VolConfirm> vcs = new ArrayList <VolConfirm>();
        List <TA> m05s = ta.getTas();
        List <String> sxbFundList = sxbFundFilterService.getSxbFundList();
        for (TA t : m05s) {
            VolConfirm vc = new VolConfirm();
            Model05 m05 = (Model05) t;
            if("1".equals(m05.getDetailFlag())){
                continue;
            }
			// 过滤不属于生息宝基金的数据
			if (!CollectionUtils.isEmpty(sxbFundList) && !sxbFundList.contains(m05.getFundCode())) {
				log.info("VolumeConfirmServiceImpl.convert : fundCode == {} does not belong to sxb",
						m05.getFundCode());
				continue;
			}
            vc.setUid(fetchUID(fundCustInfoService, m05.getTransactionAccountID()));
            vc.setTradeAccount(m05.getTransactionAccountID());
            vc.setFundAccount(m05.getTAAccountID());
            vc.setFundCode(m05.getFundCode());
            vc.setTaCode(ta.getTa());
            vc.setBalanceVol(Long.valueOf(ConvertUtils.convertToCent(m05.getTotalVolOfDistributorInTA())));
            vc.setAvailableVol(Long.valueOf(ConvertUtils.convertToCent(m05.getAvailableVol())));
            vcs.add(vc);
        }
        return vcs;
    }
    
}

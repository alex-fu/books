package com.wacai.fund.fs.service.builder;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.wacai.fund.fs.utils.FileUtils;
import com.wacai.fund.fs.utils.HXUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * HXFileBuilder
 *
 * @author mufu
 * @date 2017/11/28
 */
@Slf4j
@Service("hxFileBuilder")
public class HXFileBuilder extends AbstractFileBuilder {
    /**
     *  F004  wacai_F004_yyyymmdd.txt  ->fund_merid_F004_${tradeDate}.txt
     *  F011  wacai_F011_yyyymmdd.txt  ->fund_merid_F011_${tradeDate}.txt
     */
    private String descryptData;

    @Override
    protected void init() throws Exception{
        List<String> lines = FileUtils.readFromFile(Paths.get(getSource()));
        String line = Joiner.on("").join(lines);
        descryptData =  HXUtils.descrypt(line);
    }

    @Override
    public List<String> fetch() {
        return Lists.newArrayList(descryptData);
    }

    @Override
    public Path buildPath() {
        File file = new File(getSource());
        String newFileName = file.getName().replace("wacai","fund_merid");
        log.info("HXFileBuilder.buildPath : newFileName =={}", getDist());
        return Paths.get(file.getParent(),newFileName);
    }
}

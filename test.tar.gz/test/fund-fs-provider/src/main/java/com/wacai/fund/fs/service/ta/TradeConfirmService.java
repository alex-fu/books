package com.wacai.fund.fs.service.ta;

import com.wacai.fund.account.api.FundCustInfoService;
import com.wacai.fund.account.dto.FundCustInfoDto;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.TradeConfirm;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.parent.client.result.Result;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * TradeConfirmService interface
 *
 * @author mufu
 * @date 2017/10/7
 */
@Service
public interface TradeConfirmService {
   public List<TradeConfirm> convert(TABeans<TA> ta);

   default Long fetchUID(FundCustInfoService fundCustInfoService, String tradeAccount) {
      Result<FundCustInfoDto> fundCustInfoDtoResult = null;
      try{
         fundCustInfoDtoResult = fundCustInfoService.getFundCustInfo(tradeAccount);
      }catch(Exception e){
      }
      Long uid = Optional.ofNullable(fundCustInfoDtoResult)
              .map(Result<FundCustInfoDto>::getValue)
              .map(FundCustInfoDto::getUid)
              .orElse(123L);
      return uid;
   }
}

package com.wacai.fund.fs.process;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.service.builder.TradeConfirmFileBuilder;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * TradeACKProcessTemplate
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Service("tradeConfirmProcessTemplate")
public class TradeConfirmProcessTemplate extends BasicProcessTemplate {

    @Autowired
    TradeConfirmFileBuilder tradeConfirmFileBuilder;

    @Override
    public void parser(FsTransactionPo fsTransactionPo) {
        try {
			tradeConfirmFileBuilder.build(fsLocalPath(fsTransactionPo), fsTransactionPo.getUploadFilePattern());
			fsTransactionPo.setUploadFilePattern(tradeConfirmFileBuilder.getNewGenerateFile());
        } catch (Exception e) {
        	BizMonitor.report(new MInfo(MtraceEnum.FS_04_06_TASK.getCode(), ActionEnum.TRADE_CONFIRM_PROCESS.getCode(), ResultEnum.FAILED.getCode(), "交易确认文件处理失败，解析失败"));
			log.error("tradeConfirmProcessTemplate.parser happen Exception", e);
		}
    }

    private String fsLocalPath(FsTransactionPo fsTransactionPo) {
        log.info("tradeConfirmProcessTemplate.fsLocalPath : downloadFilePattern==", fsTransactionPo.getDownloadFilePattern());
        if (StringUtils.isNotEmpty(fsTransactionPo.getDownloadFilePattern())) {
            List <String> files = Splitter.on(",").splitToList(fsTransactionPo.getDownloadFilePattern());
            List <String> newFiles = new ArrayList <>();
            files.stream().forEach(file -> newFiles.add(getCurrentDirectory() + File.separator + file));
            return Joiner.on(",").join(newFiles);
        }
        return null;
    }

    @Override
    public TaskType getType() {
        return TaskType.TASK_2;
    }
}

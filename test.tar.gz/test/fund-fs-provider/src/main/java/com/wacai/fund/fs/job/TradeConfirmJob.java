package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.TradeConfirmProcessTemplate;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.utils.TaskIdUtils;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * TradeConfirmJob
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Component("tradeConfirmJob")
public class TradeConfirmJob implements Job {

    @Autowired
    TradeConfirmProcessTemplate tradeConfirmProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;
    
    @Autowired
    FundTradeDayService fundTradeDayService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution TradeConfirmJob Transaction------");
        long start = System.nanoTime();
        try {
        	String taskId = generateTaskId();
			if (StringUtils.isNotBlank(taskId)) {
	            FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(taskId);
	            tradeConfirmProcessTemplate.process(fsTransactionPo);
			}
        } catch (Exception e) {
            log.error("TradeConfirmJob doExecute error", e);
        }
        long end = System.nanoTime();
        log.info("----TradeConfirmJob finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end-start));
    }

	/**
	 * generateTaskId:获取交易确认的任务id
	 * @return
	 * @author qingniu
	 * @date 2017年12月18日 下午7:43:07
	 */
	private String generateTaskId() {
		String taskId = "";
		try {
			String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
			//交易确认的前置条件是账户确认，如果账户确认未执行成功，不执行交易确认
			if (preCheckTradeConfirm(tradeDate)) {
				taskId = TaskIdUtils.generateId(tradeDate, TaskType.TASK_2.getValue());
			}
			log.info("generateTaskId : tradeDate == {}; taskId == {}", tradeDate, taskId);
		} catch (Exception e) {
			log.error("generateTaskId happen Exception", e);
		}
		return taskId;
	}
	
	/**
	 * preCheckTradeConfirm:交易确认前置校验，校验账户确认是否处理完成
	 * @param tradeDate
	 * @return
	 * @author qingniu
	 * @date 2018年1月8日 上午11:20:57
	 */
	private boolean preCheckTradeConfirm(String tradeDate) {
		boolean preCheckFlag = false;
		String accountConfirmTaskId = TaskIdUtils.generateId(tradeDate, TaskType.TASK_1.getValue());
		FsTransactionPo fsTransaction = fsTransactionPoService.getByTaskId(accountConfirmTaskId);
		if (null != fsTransaction && fsTransaction.getFinishStatus()
				&& ConfirmType.SUCCESS.getValue().equals(fsTransaction.getConfirmStatus())) {
			preCheckFlag = true;
		}
		log.info("preCheckTradeConfirm : tradeDate == {}; preCheckFlag == {}", tradeDate, preCheckFlag);
		return preCheckFlag;
	}

}
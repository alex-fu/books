package com.wacai.fund.fs.client;

//@Configuration
//@EnableAutoConfiguration
//@ComponentScan(value={"com.wacai.fund.fs","com.wacai.fund.parent.service.net", "com.wacai.fund.parent.ds"})
public class BaseConfig {

}

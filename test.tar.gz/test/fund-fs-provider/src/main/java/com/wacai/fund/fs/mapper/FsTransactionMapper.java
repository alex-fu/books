package com.wacai.fund.fs.mapper;


import com.wacai.fund.fs.bean.task.FsTransactionPo;

/**
 * 任务流水表的Mapper类
 * Table: fs_transaction - 任务流水表
 *
 * @author mufu
 * @date 2017-11-23 08:24:56
 */
public interface FsTransactionMapper {

	/**
	 * 新增
	 * @param fsTransactionPo
	 * @return
	 */
	int insert(FsTransactionPo fsTransactionPo);

	/**
	 * 修改
	 * @param fsTransactionPo
	 * @return
	 */
	int update(FsTransactionPo fsTransactionPo);

	/**
	 * 根据主键查询
	 * @param id
	 * @return
	 */
	FsTransactionPo selectByPrimaryKey(Long id);

	/**
	 * 根据taskId查询
	 * @param taskId
	 * @return
	 */
	FsTransactionPo selectByTaskId(String taskId);
	
}

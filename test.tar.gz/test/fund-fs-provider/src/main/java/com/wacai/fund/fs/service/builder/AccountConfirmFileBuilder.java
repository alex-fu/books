package com.wacai.fund.fs.service.builder;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.output.AccountConfirm;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.service.ta.AccountConfirmService;

import lombok.extern.slf4j.Slf4j;

/**
 * AccountConfirmFileBuilder
 *
 * @author mufu
 * @date 2017/11/22
 */
@Slf4j
@Service("accountConfirmFileBuilder")
public class AccountConfirmFileBuilder extends AbstractFileBuilder {

    private static final Template TEMPLATE = new Template(TAType.TA_02);

    private static final TAParser TA_PARSER = TAParser.getInstance();

    private TABeans<TA> tab02;

    @Autowired
    @Qualifier("accountConfirmServiceImpl")
    AccountConfirmService accountConfirmService;


	@Override
    public void init()throws Exception{
        tab02 = TA_PARSER.buildFromTA(getSource(), TEMPLATE);
        log.info("AccountConfirmFileBuilder build init successful!!!");
    }

    @Override
    public List<String> fetch() {
        List <String> lines = new ArrayList<>();
        List<AccountConfirm> tc02 = accountConfirmService.convert(tab02);
        tc02.stream().map(AccountConfirm::toString).forEach(lines::add);
        log.info("accountConfirmFileBuilder.fetch : lines == {} ", lines);
        return lines;
    }

    @Override
    public Path buildPath() {
        File file = new File(super.getSource());
        Path path = Paths.get(file.getParent(), super.getDist());
        log.info("accountConfirmFileBuilder.buildPath : fileName = {}",path.getFileName());
        return path;
    }
}

package com.wacai.fund.fs.bean.output;

import java.io.Serializable;
import java.util.List;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import lombok.Data;

/**
 * VolConfirm class
 * from 05 file
 * <p>
 * from
 * OFD_98_152_20170707_05.TXT
 * <p>
 * to
 * fund_vol_chk_${taCode}_${tradeDate}.txt
 *
 * @author mufu
 * @date 2017/11/01
 */
@Data
public class VolConfirm implements Serializable {

    private static final long serialVersionUID = 3046443143014250L;

    private Long uid;          //invoke fund-account
    private String tradeAccount;  //TransactionAccountID
    private String fundAccount;    //TAAccountID
    private String fundCode;      //FundCode
    private String taCode;      //retrieve from file
    private Long balanceVol;     //TotalVolOfDistributorInTA
    private Long availableVol;

    @Override
    public String toString() {
        List <Object> list = Lists.newArrayList(this.uid, this.tradeAccount, this.fundAccount, this.fundCode, this.taCode, this.balanceVol, this.availableVol);
        return Joiner.on("|").useForNull("").join(list);
    }
}

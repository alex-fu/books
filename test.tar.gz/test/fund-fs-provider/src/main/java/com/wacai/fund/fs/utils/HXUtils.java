package com.wacai.fund.fs.utils;

import com.wacai.fund.parent.lang.utils.DESedeUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * HXUtils
 *
 * @author mufu
 * @date 2017/10/31
 */
@Slf4j
public class HXUtils {
    private static final String KEY = "123456789012345678901234567890123456789012345678";
    
    private HXUtils() {
	}

    public static String descrypt(String data) {
        log.info("the message before decryption is {}", data);
        try {
            byte[] bytes = DESedeUtil.decryptDes3CBC(KEY, data);
            String plantext = new String(bytes, "GBK");
            log.info("the message after decryption is {}", plantext);
            return plantext;
        } catch (Exception e) {
            log.error("the decryption failed", e);
        }
        return null;
    }
}

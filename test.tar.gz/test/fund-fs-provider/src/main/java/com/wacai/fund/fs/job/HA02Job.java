package com.wacai.fund.fs.job;

import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.HA02ProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * @author jingfan
 * @description: 华安份额划转结果文件Job
 * @date 2018/2/6 下午5:09
 * @since JDK 1.8
 */
@Slf4j
@Component("hA02Job")
public class HA02Job implements Job {

    @Autowired
    private HA02ProcessTemplate hA02ProcessTemplate;

    @Autowired
    private FsTransactionPoService fsTransactionPoService;

    @Autowired
    private FundTradeDayService fundTradeDayService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution HA02Job Transaction------");
        long start = System.nanoTime();
        try {
            FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(generateTaskId());
            if(fsTransactionPo != null)
                hA02ProcessTemplate.process(fsTransactionPo);
        } catch (Exception e) {
            log.error("HA02Job doExecute error,e=", e);
        }
        long end = System.nanoTime();
        log.info("----HA02Job finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end - start));
    }

    private String generateTaskId() {
        String taskId = "";
        try {
            String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
            if(StringUtils.isNotBlank(tradeDate)){
                taskId = tradeDate + TaskType.TASK_10.getValue();
            }
            log.info("generateTaskId : tradeDate == {}; taskId == {}", tradeDate, taskId);
        } catch (Exception e) {
            log.error("generateTaskId happen Exception", e);
        }
        return taskId;
    }
}

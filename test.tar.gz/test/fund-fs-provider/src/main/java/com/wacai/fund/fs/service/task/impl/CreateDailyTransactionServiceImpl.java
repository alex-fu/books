package com.wacai.fund.fs.service.task.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.service.task.CreateDailyTransactionService;
import com.wacai.fund.fs.service.task.FsTemplatePoService;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * CreateDailyTransactionServiceImpl
 *
 * @author mufu
 * @date 2017/11/23
 */
@Service
@Slf4j
public class CreateDailyTransactionServiceImpl implements CreateDailyTransactionService {

    @Autowired
    FsTemplatePoService fsTemplatePoService;

    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Override
    public void createDailyTransaction(){
		try {
			List<FsTemplatePo> fsTemplatePoList = fsTemplatePoService.getAllTemplate();
			log.info("fsTemplatePoList=[" + fsTemplatePoList + "]");
			fsTransactionPoService.createtTransaction(fsTemplatePoList);
		} catch (Exception e) {
			BizMonitor.report(new MInfo(MtraceEnum.FS_TASK_INIT.getCode(), ActionEnum.CREATE_FILE_JOB.getCode(),
					ResultEnum.FAILED.getCode(), "文件系统任务模板初始化失败：" + e.getMessage()));
			log.error("createDailyTransaction happen exception", e);
		}
    }
}

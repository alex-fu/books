package com.wacai.fund.fs.exception;

import com.wacai.fund.fs.enums.FSExceptionCode;
import org.apache.commons.lang3.StringUtils;

/**
 * FSRuntimeException
 *
 * @author mufu
 * @date 2017/11/06
 */
public class FSRuntimeException extends RuntimeException {

	private static final long serialVersionUID = -1627792540982074303L;

	private FSExceptionCode code;

    protected String message;

    protected Class <?> clazz;

    protected Throwable throwable;

    protected FSRuntimeException(Class <?> clazz) {
        this.clazz = clazz;
    }

    protected FSRuntimeException(String message, Object... values) {
        this.setMessage(message, values);
    }

    public FSRuntimeException(Throwable throwable, String message, Object... values) {
        super(throwable);
        this.setMessage(message, values);
        this.throwable = throwable;
    }

    public FSRuntimeException(Class <?> clazz, FSExceptionCode code, Object... values) {
        this(clazz);
        this.code = code;
        if (code != null) {
            this.setMessage(code.getDescription(), values);
        }
    }

    public FSRuntimeException(Class <?> clazz, Throwable throwable, FSExceptionCode code, Object... values) {
        super(throwable);
        this.clazz = clazz;
        this.code = code;
        if (code != null) {
            this.setMessage(code.getDescription(), values);
        }
        this.throwable = throwable;
    }

    public FSRuntimeException(Class <?> clazz, String message, Object... values) {
        super(String.format("ErrMsg: %s", message));
        this.clazz = clazz;
        this.message = message;
    }

    public FSRuntimeException(Class <?> clazz, Throwable throwable) {
        super(throwable);
        this.throwable = throwable;
    }

    public FSRuntimeException(Class <?> clazz, Throwable throwable, String message, Object... values) {
        super(String.format("ErrMsg: %s", message), throwable);
        this.clazz = clazz;
        this.setMessage(message, values);
        this.throwable = throwable;
    }

    public String getCode() {
        return code != null ? code.getValue() : null;
    }

    @Override
    public String getMessage() {
        if (StringUtils.isNotEmpty(message)) {
            return message;
        }
        return code != null ? code.getDescription() : null;
    }

    public Class <?> getClazz() {
        return clazz;
    }

    public Throwable getThrowable() {
        return throwable;
    }

    protected void setMessage(String message, Object[] values) {
        if (values == null) {
            this.message = message;
        } else {
            this.message = String.format(message, values);
        }
    }
}

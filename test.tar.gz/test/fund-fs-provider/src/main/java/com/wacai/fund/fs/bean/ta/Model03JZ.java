package com.wacai.fund.fs.bean.ta;

import java.util.Map;

import com.google.common.base.Joiner;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.utils.ConvertUtils;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Model03JZ class
 *
 * @author mufu
 * @date 2017/11/01
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Model03JZ extends Model03 {

    private static final long serialVersionUID = 2038012262172966361L;

    private String Realpaycenterid;   //the real wacai payment channel
    private String PayStatus;    //default as '00', 02 for wacai


    @Override
    public String toString(){
        Map<String, Object> map = ConvertUtils.sortAsFieldWithOriginalValue(this, new Template(TAType.TA_03JZ));
        return Joiner.on("").join(map.values());
    }
}

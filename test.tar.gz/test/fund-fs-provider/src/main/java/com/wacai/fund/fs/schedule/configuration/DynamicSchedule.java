package com.wacai.fund.fs.schedule.configuration;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.concurrent.ScheduledFuture;

/**
 * DynamicSchedule
 *
 * @author mufu
 * @date 2017/11/28
 */
@Data
@Service
public class DynamicSchedule {
    private static final int THREAD_POOL_SIZE = 1;
    
    @Autowired
    private ThreadPoolTaskScheduler threadPoolTaskScheduler;

    private ScheduledFuture <?> future;

    private String cron = "0 0 0 0 0 ?";
    
    private Runnable runnable;

    @Bean
    public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
        threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.initialize();
        threadPoolTaskScheduler.setPoolSize(THREAD_POOL_SIZE);
        return threadPoolTaskScheduler;
    }


    public void start() {
        stopCron();
        future = threadPoolTaskScheduler.schedule(runnable, new Trigger() {
            @Override
            public Date nextExecutionTime(TriggerContext triggerContext) {
                if ("".equals(cron) || cron == null) {
                    return null;
                }
                CronTrigger trigger = new CronTrigger(cron);
                return trigger.nextExecutionTime(triggerContext);
            }
        });
    }

    public void stopCron() {
        if (future != null) {
            future.cancel(true);
        }
    }
}

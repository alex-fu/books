package com.wacai.fund.fs.bean.output;

import java.io.Serializable;
import java.util.List;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import lombok.Data;

/**
 * TradeConfirm class
 * from 04/06 file
 * from
 * OFD_98_152_20170707_04.TXT
 * OFD_07_304_20141027_06.TXT
 * <p>
 * to
 * fund_trade_ack_${taCode}_${tradeDate}.txt
 *
 * @author mufu
 * @date 2017/11/01
 */
@Data
public class TradeConfirm implements Serializable {

    private static final long serialVersionUID = 3694393012241836606L;

    private Long uid;       //invoke   fund-account
    private String tradeAccount; //TransactionAccountID
    private String fundAccount;   //TAAccountID
    private String tradeNo;      //AppSheetSerialNo
    private String ackNo;        //TASerialNo
    private String busiCode;    //BusinessCode
    private String fundCode;    //FundCode
    private String taCode;      //retrieve from file
    private String ackDate;     //TransactionCfmDate
    private Long ackAmt;        //ConfirmAmount
    private String retCode;     //ReturnCode
    private String retMsg;      //Specification
	private Long frozenReinvestVol; // FrozenSharesforReinvest 冻结再投资份额

	@Override
	public String toString() {
		List<Object> list = Lists.newArrayList(this.uid, this.tradeAccount, this.fundAccount, this.tradeNo, this.ackNo,
				this.busiCode, this.fundCode, this.taCode, this.ackDate, this.ackAmt, this.retCode, this.retMsg,
				this.frozenReinvestVol);
		return Joiner.on("|").useForNull("").join(list);
	}

}

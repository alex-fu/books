package com.wacai.fund.fs.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wacai.fund.fs.bean.core.Field;
import com.wacai.fund.fs.constant.TaConstant;
import com.wacai.fund.fs.enums.TAType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * TemplateUtils class
 *
 * @author mufu
 * @date 2017/10/31
 */
@Slf4j
public class TemplateUtils {

    public static final Charset UTF_8 = StandardCharsets.UTF_8;
    
	private TemplateUtils() {
	}

    public static List <Field> loadTemplate(TAType type) {
        String config = TaConstant.getTaMap().get(type);
        log.debug("the config is {}", config);
        try {
            return loadTemplate(config);
        } catch (IOException e) {
            log.error("loadTemplate happen Excetion", e);
        }
        return Collections.emptyList();
    }


    public static List <Field> loadTemplate(String file) throws IOException {
        List <Field> fields = new ArrayList <>();
        try (BufferedReader br = getResourceWithDefaultCharset(file)) {
            String line;
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = br.readLine()) != null) {
                stringBuilder.append(line);
            }
            JSONObject jsonData = JSON.parseObject(stringBuilder.toString());
            JSONArray seriesArray = jsonData.getJSONArray("fields");
            fields = JSON.parseArray(seriesArray.toString(), Field.class);
        } catch (Exception e) {
            log.error("loadTemplate error, reason {}", e);
        }
        return fields;
    }

    private static BufferedReader getResourceWithDefaultCharset(String path) throws IOException {
        return getResource(path, UTF_8);
    }

    private static BufferedReader getResource(String path, Charset cs) throws IOException {
        Assert.notNull(path, "resource file must not be null");
        Resource resource = new ClassPathResource(path);
        if (!resource.exists()) {
            throw new IOException("template resource file not exists!!!");
        }
        CharsetDecoder decoder = cs.newDecoder();
        Reader reader = new InputStreamReader(resource.getInputStream(), decoder);
        return new BufferedReader(reader);
    }


//    public static void main(String []args){
//        List <Field>  fields =  loadTemplate(TAType.TA_07);
//        int len=0;
//        for(Field field : fields){
//            log.debug(field.getName());
//            len+=field.getLength();
//        }
//        log.debug("The length="+len);
//    }

}

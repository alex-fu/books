package com.wacai.fund.fs.bean.task;


import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>任务流水表的实体类</p>
 * <p>Table: fs_transaction - 任务流水表</p>
 *
 * @author mufu
 * @date 2017-11-23 08:24:56
 */
@Data
public class FsTransactionPo implements Serializable{

    private static final long serialVersionUID = -5825111196434305919L;
    /** id -  */
    private Long id;
	
	/** task_id - 任务ID */
    private String taskId;
	
	/** task_name -  */
    private String taskName;
	
	/** provider -  */
    private Integer provider;
	
	/** provider_path -  */
    private String providerPath;
	
	/** receiver -  */
    private Integer receiver;
	
	/** receiver_path -  */
    private String receiverPath;
	
	/** download -  */
    private Boolean downloadStatus;
	
	/** upload -  */
    private Boolean uploadStatus;
	
	/** file_name -  */
    private String downloadFilePattern;

    /** upload_file_name **/
    private String uploadFilePattern;

    /** file type- */
    private Integer fileType;
	
	/** is_finish -  */
    private Boolean finishStatus;

    /** is_confirm -  */
    private Integer confirmStatus;

    /**wait_ack_time**/
    private Integer waitAckTime;

    /** is_lock **/
    private Boolean lockStatus;

    /** is_alert **/
    private Boolean alertStatus;
	
	/** message -  */
    private String message;
	
	/** created_time - 创建时间 */
    private Date createdTime;
	
	/** updated_time - 修改时间 */
    private Date updatedTime;

}
package com.wacai.fund.fs.service.builder;

import com.wacai.fund.fs.utils.FileUtils;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.List;

/**
 * FileBuilder interface
 *
 * @author mufu
 * @date 2017/10/22
 */
@Service
public interface FileBuilder {
	//获取文件内容
    public List<String> fetch();

    //写文件的路径和位置
    public Path buildPath();

    default void build(){
        FileUtils.writeToFile(fetch(), buildPath());
    }
}

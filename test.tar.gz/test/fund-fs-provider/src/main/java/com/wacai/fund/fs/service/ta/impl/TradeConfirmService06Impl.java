package com.wacai.fund.fs.service.ta.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.wacai.fund.account.api.FundCustInfoService;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.output.TradeConfirm;
import com.wacai.fund.fs.bean.ta.Model06;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.service.ta.SxbFundFilterService;
import com.wacai.fund.fs.service.ta.TradeConfirmService;
import com.wacai.fund.fs.utils.ConvertUtils;

import lombok.extern.slf4j.Slf4j;


/**
 * TradeConfirmService06Impl
 *
 * @author mufu
 * @date 2017/11/17
 */
@Slf4j
@Service
public class TradeConfirmService06Impl implements TradeConfirmService {

    @Autowired
    FundCustInfoService fundCustInfoService;
    
    @Autowired
	private SxbFundFilterService sxbFundFilterService;

    @Override
    public List <TradeConfirm> convert(TABeans <TA> ta) {
        List <TradeConfirm> tcs = new ArrayList <TradeConfirm>();
        List <TA> m06s = ta.getTas();
        List <String> sxbFundList = sxbFundFilterService.getSxbFundList();
        for (TA t : m06s) {
            TradeConfirm tc = new TradeConfirm();
            Model06 m06 = (Model06) t;
			// 过滤不属于生息宝基金的数据
			if (!CollectionUtils.isEmpty(sxbFundList) && !sxbFundList.contains(m06.getFundCode())) {
				log.info("TradeConfirmService06Impl.convert : fundCode == {} does not belong to sxb",
						m06.getFundCode());
				continue;
			}
            tc.setUid(fetchUID(fundCustInfoService, m06.getTransactionAccountID()));
            tc.setTradeAccount(m06.getTransactionAccountID());
            tc.setFundAccount(m06.getTAAccountID());
            tc.setAckNo(m06.getTASerialNO());
            tc.setBusiCode(m06.getBusinessCode());
            tc.setFundCode(m06.getFundCode());
            tc.setTaCode(ta.getTa());
            tc.setAckDate(m06.getTransactionCfmDate());
            /**
             *  DefDividendMethod
             *
             *  0 divided reinvestment   VolOfDividendforReinv
             *  1 cash bonus   ConfirmedAmount
             */
            if ("0".equals(m06.getDefDividendMethod())) {
                tc.setAckAmt(Long.valueOf(ConvertUtils.convertToCent(m06.getVolOfDividendforReinvestment())));
            } else {
                tc.setAckAmt(Long.valueOf(ConvertUtils.convertToCent(m06.getConfirmedAmount())));
            }
            tc.setRetCode(m06.getReturnCode());
            //冻结再投资份额
            if (m06.getFrozenSharesforReinvest() !=null && m06.getFrozenSharesforReinvest().doubleValue()>0) {
            	tc.setFrozenReinvestVol(Long.valueOf(ConvertUtils.convertToCent(m06.getFrozenSharesforReinvest())));
			}
            tcs.add(tc);
        }
        return tcs;
    }
    
}

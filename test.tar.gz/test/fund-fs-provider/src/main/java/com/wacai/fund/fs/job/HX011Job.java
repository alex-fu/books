package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.HX011ProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.utils.DateUtils;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * TradeConfirmJob
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Component("hx011Job")
public class HX011Job implements Job {

    @Autowired
    HX011ProcessTemplate hx011ProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution HX011Job Transaction------");
        long start = System.nanoTime();
        try{
            FsTransactionPo fsTransactionPo =fsTransactionPoService.getByTaskId(generateTaskId());
            hx011ProcessTemplate.process(fsTransactionPo);
        }catch(Exception e){
            log.error("HX011Job doExecute error,e=", e);
        }
        long end = System.nanoTime();
        log.info("----HX011Job finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end-start));
    }

    /** through the template to find transaction **/
    private String generateTaskId(){
        return DateUtils.getCurrentDate()+ TaskType.TASK_7.getValue();
    }

}
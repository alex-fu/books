package com.wacai.fund.fs.process;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.service.builder.AccountConfirmFileBuilder;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * AccountConfirmProcessTemplate
 *
 * @author mufu
 * @date 2017/11/27
 */
@Slf4j
@Service("accountConfirmProcessTemplate")
public class AccountConfirmProcessTemplate extends BasicProcessTemplate {

    @Autowired
    AccountConfirmFileBuilder accountConfirmFileBuilder;

    @Override
    public void parser(FsTransactionPo fsTransactionPo){
    	try {
			String source = getCurrentDirectory() + File.separator + fsTransactionPo.getDownloadFilePattern();
			String dist = fsTransactionPo.getUploadFilePattern();
			log.info("accountConfirmProcessTemplate.parser : source == {};dist =={}", source, dist);
			accountConfirmFileBuilder.build(source, dist);
		} catch (Exception e) {
			BizMonitor.report(new MInfo(MtraceEnum.FS_02_TASK.getCode(), ActionEnum.ACCOUNT_CONFIRM_PROCESS.getCode(), ResultEnum.FAILED.getCode(), "账户确认文件处理失败，解析失败"));
			log.error("accountConfirmProcessTemplate.parser happen Exception", e);
		}
    }

    @Override
    public TaskType getType() {
        return TaskType.TASK_1;
    }
}

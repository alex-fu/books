package com.wacai.fund.fs.bean.core;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.constant.TaConstant;
import com.wacai.fund.fs.utils.ConvertUtils;
import com.wacai.fund.fs.utils.FileUtils;

//import com.wacai.fund.parent.monitor.BizMonitor;
//import com.wacai.fund.parent.monitor.MInfo;
import lombok.extern.slf4j.Slf4j;


/**
 * TAParser class
 *
 * @author mufu
 * @date 2017/10/31
 */
@Slf4j
public class TAParser {
    private static TAParser taBuild = new TAParser();

    private TAParser() {
    }

    public static TAParser getInstance() {
        return taBuild;
    }

    /**
     * build from sxb
     * @param sxbFile
     * @param template
     * @return TABeans
     */
    public TABeans<TA> buildFromSXB(String sxbFile, Template template) {
        TABeans<TA> tab = new TABeans<>();
        if (isEmpty(sxbFile) || !Paths.get(sxbFile).toFile().exists()) {
            try {
                throw new FileNotFoundException("sxb file" + sxbFile + " not exists!!!");
            } catch (FileNotFoundException e) {
                log.error("buildFromSXB error, reason {}",e);
            }
        }
        String[] infos = new File(sxbFile).getName().split("_");
        //OFD_SA_TA_yyyyMMdd_0X.TXT
        if (infos.length < 5) {
            try {
                throw new FileNotFoundException("ta file damage!!!");
            } catch (FileNotFoundException e) {
                log.error("buildFromSXB error, reason {}",e);
            }
        }
        tab.setTa(infos[2]);
        tab.setSa(infos[1]);
        tab.setTradeDate(infos[3]);

        Path path = Paths.get(sxbFile);
        List <String> lines = FileUtils.readFromFile(path);
        List <TA> tas = new ArrayList <>();
        for (String line : lines) {
            tas.add(getTA(line, "\\|", template));
        }
        tab.setTas(tas);
        return tab;
    }

    private TA getTA(String line, String separator, Template template) {
        if (StringUtils.isEmpty(line) || StringUtils.isEmpty(separator)) {
            try {
                throw new Exception("");
            } catch (Exception e) {
                log.error("getTA error, reason {}",e);
            }
        }
        String[] lines = line.split(separator, -1);
        if (lines.length != template.getFields().size()) {
            try {

                throw new Exception("file parser failed!!!");
            } catch (Exception e) {
                log.error("the lines length ={},but expected = {}", lines.length, template.getFields().size());
            }
        }
        TA ta = null;
        Map <String, Object> map = new HashMap <>();
        List <Field> fields = template.getFields();
        try {
            for (int i = 0; i < fields.size(); i++) {
                Field field = fields.get(i);
                map.put(field.getName(), ConvertUtils.convertObject(field, lines[i]));
            }
            ta = mapToBean(map, template);
        } catch (Exception e) {
            log.error("line to TA convert failed, {}", e);
        }
        return ta;
    }

    /**
     * build from TA
     * @param taFile
     * @param template
     * @return TABeans
     */
    public TABeans<TA> buildFromTA(String taFile, Template template) {
        TABeans<TA> tab = new TABeans<>();
        if (isEmpty(taFile) || Files.notExists(Paths.get(taFile))) {
            try {
                throw new FileNotFoundException("ta file not exists!!!");
            } catch (FileNotFoundException e) {
                log.error("buildFromTA error, reason {}", e);
            }
        }
        String[] infos = new File(taFile).getName().split("_");
        //OFD_TA_SA_yyyyMMdd_0X.TXT
        if (infos.length < 5) {
            try {
                throw new FileNotFoundException("ta file damage!!!");
            } catch (FileNotFoundException e) {
                log.error("the file not found", taFile);
            }
        }
        tab.setTa(infos[1]);
        tab.setSa(infos[2]);
        tab.setTradeDate(infos[3]);

        int length = template.getLength();
        Path path = Paths.get(taFile);
        Map <String, Object> maps = null;
        try (BufferedReader br = Files.newBufferedReader(path,
                StandardCharsets.ISO_8859_1)) {
            List <TA> tas = new ArrayList <TA>();
            String line = null;
            while ((line = br.readLine()) != null) {
                if (line != null && line.length() == length) {
                    log.info(new String(line.getBytes("ISO-8859-1"), "GBK"));
                    maps = handle(line, template.getFields());
                    tas.add(mapToBean(maps, template));
                }
            }
            if (tas.size() == 0) {
//                throw new Exception("the file no data"); no data is availiable
                log.info("no data in this file={}", taFile);
            }
            tab.setTas(tas);
        } catch (Exception e) {
            log.error("TABeans convert failed!!!, reason: {}", e);
        }
        return tab;
    }

    /**
     * parser line as template
     * @param line
     * @param fields
     * @return Maps
     * @throws Exception
     */
    private Map <String, Object> handle(String line, List <Field> fields) throws Exception {
        Map <String, Object> maps = new LinkedHashMap <String, Object>();
        int start = 0;
        int end = 0;
        String detailsField = null;
        try {
            for (Field field : fields) {
                end = start + field.getLength();
                String value = line.substring(start, end);
                detailsField = "[ " + start + "," + end + "] " + field.getName() + "=" + new String(value.getBytes("ISO-8859-1"), "GBK") + "[checklength]="
                        + field.getLength() + "--" + field.getType() + "--" + field.getPrecision();
                start = end;
                maps.put(field.getName(), ConvertUtils.convert(field, value));
            }
        } catch (Exception e) {
            log.error("handle : detailsField =={}", detailsField, e);
        }
        return maps;
    }


    /**
     * transfer map to Bean
     * @param maps
     * @param template
     * @return TA
     * @throws Exception
     */
    private TA mapToBean(Map <String, Object> maps, Template template) throws Exception {
        TA t = (TA) TaConstant.getTaMapClass().get(template.getType()).newInstance();
        t = (TA) ConvertUtils.mapToObject(maps, t.getClass());
        return t;
    }
}

package com.wacai.fund.fs.service.task.impl;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.mapper.FsTemplateMapper;
import com.wacai.fund.fs.service.task.FsTemplatePoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TaskTemplateServiceImpl
 *
 * @author mufu
 * @date 2017/11/17
 */

@Service
public class FsTemplatePoServiceImpl implements FsTemplatePoService {

    @Autowired
    FsTemplateMapper fsTemplateMapper;

    @Override
    public List<FsTemplatePo> getAllTemplate() {
        return fsTemplateMapper.selectAllTemplate();
    }

}

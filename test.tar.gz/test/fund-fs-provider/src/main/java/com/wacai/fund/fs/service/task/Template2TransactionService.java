package com.wacai.fund.fs.service.task;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.bean.task.FsTransactionPo;

/**
 * Template2TransactionService interface
 *
 * @author mufu
 * @date 2017/10/17
 */
public interface Template2TransactionService {
    public FsTransactionPo generate(FsTemplatePo template);
}

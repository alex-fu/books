package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.TA07ProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * TA07Job
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Component("ta07Job")
public class TA07Job implements Job {

    @Autowired
    TA07ProcessTemplate ta07ProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;
    
    @Autowired
    FundTradeDayService fundTradeDayService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution TA07Job Transaction------");
        long start = System.nanoTime();
        try{
			String taskId = generateTaskId();
			if (StringUtils.isNotBlank(taskId)) {
				FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(taskId);
				ta07ProcessTemplate.process(fsTransactionPo);
			}
        }catch(Exception e){
            log.error("TA07Job doExecute error,e=", e);
        }
        long end = System.nanoTime();
        log.info("----TA07Job finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end-start));
    }

    /**
	 * generateTaskId:获取基金行情的任务id
	 * @return
	 * @author qingniu
	 * @date 2017年12月18日 下午7:43:07
	 */
	private String generateTaskId() {
		String taskId = "";
		try {
			String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
			if(StringUtils.isNotBlank(tradeDate)){
				 taskId = tradeDate + TaskType.TASK_4.getValue();
			}
			log.info("generateTaskId : tradeDate == {}; taskId == {}", tradeDate, taskId);
		} catch (Exception e) {
			log.error("generateTaskId happen Exception", e);
		}
		return taskId;
	}

}
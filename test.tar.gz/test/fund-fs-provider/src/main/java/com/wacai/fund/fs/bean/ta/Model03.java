package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * Model03 class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model03 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6740620068701891863L;

	private String AppSheetSerialNo;
	private String FundCode;
	private String LargeRedemptionFlag;
	private String TransactionDate;
	private String TransactionTime;
	private String TransactionAccountID;
	private String DistributorCode;
	private BigDecimal ApplicationVol;
	private BigDecimal ApplicationAmount;
	private String BusinessCode;
	private String TAAccountID;
	private BigDecimal DiscountRateOfCommission;
	private String DepositAcct;
	private String RegionCode;
	private String CurrencyType;
	private String BranchCode;
	private String OriginalAppSheetNo;
	private String OriginalSubsDate;
	private String IndividualOrInstitution;
	private BigDecimal ValidPeriod;
	private BigDecimal DaysRedemptionInAdvance;
	private String RedemptionDateInAdvance;
	private String OriginalSerialNo;
	private String DateOfPeriodicSubs;
	private String TASerialNO;
	private BigDecimal TermOfPeriodicSubs;
	private String FutureBuyDate;
	private String TargetDistributorCode;
	private BigDecimal Charge;
	private String TargetBranchCode;
	private String TargetTransactionAccountID;
	private String TargetRegionCode;
	private BigDecimal DividendRatio;
	private String Specification;
	private String CodeOfTargetFund;
	private BigDecimal TotalBackendLoad;
	private String ShareClass;
	private String OriginalCfmDate;
	private String DetailFlag;
	private String OriginalAppDate;
	private String DefDividendMethod;
	private String FrozenCause;
	private String FreezingDeadline;
	private String VarietyCodeOfPeriodicSubs;
	private String SerialNoOfPeriodicSubs;
	private String RationType;
	private String TargetTAAccountID;
	private String TargetRegistrarCode;
	private String NetNo;
	private String CustomerNo;
	private String TargetShareType;
	private String RationProtocolNo;
	private String BeginDateOfPeriodicSubs;
	private String EndDateOfPeriodicSubs;
	private BigDecimal SendDayOfPeriodicSubs;
	private String Broker;
	private String SalesPromotion;
	private String AcceptMethod;
	private String ForceRedemptionType;
	private String TakeIncomeFlag;
	private String PurposeOfPeSubs;
	private BigDecimal FrequencyOfPeSubs;
	private String PeriodSubTimeUnit;
	private BigDecimal BatchNumOfPeSubs;
	private String CapitalMode;
	private String DetailCapticalMode;
	private BigDecimal BackenloadDiscount;
	private String CombineNum;
	private String FutureSubscribeDate;
	private String TradingMethod;
	private String LargeBuyFlag;
	private String ChargeType;
	private BigDecimal SpecifyRateFee;
	private BigDecimal SpecifyFee;

}

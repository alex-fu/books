package com.wacai.fund.fs.service.builder;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.ta.Model07;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.service.ta.SxbFundFilterService;

import lombok.extern.slf4j.Slf4j;

/**
 * TA07FileBuilder
 *
 * @author mufu
 * @date 2017/11/30
 */
@Slf4j
@Service("ta07FileBuilder")
public class TA07FileBuilder extends AbstractFileBuilder {
    private static final Template TEMPLATE = new Template(TAType.TA_07);

    private static final TAParser TA_PARSER = TAParser.getInstance();

    private TABeans<TA> tab;

    private static final String CODE = "000217";

    @Autowired
	private SxbFundFilterService sxbFundFilterService;

    @Override
    protected void init() {
        tab = TA_PARSER.buildFromTA(getSource(), TEMPLATE);
        log.info("07File FileBuilder build init successful!!!");
    }

    @Override
    public List<String> fetch() {
        List<String> lines = new ArrayList<>();
        List <String> sxbFundList = sxbFundFilterService.getSxbFundList();
        sxbFundList = new ArrayList<>(sxbFundList);
        sxbFundList.add(CODE);
        List <TA> m07s = tab.getTas();
        if (!CollectionUtils.isEmpty(m07s)) {
        	for (TA t : m07s) {
        		Model07 model07 = (Model07) t;
                // 过滤不属于生息宝基金的数据
    			if (!CollectionUtils.isEmpty(sxbFundList) && !sxbFundList.contains(model07.getFundCode())) {
    				log.info("TA07FileBuilder.fetch : fundCode == {} does not belong to sxb",
    						model07.getFundCode());
    				continue;
    			}
    			log.info("TA07FileBuilder.fetch : fundCode == {} ", model07.getFundCode());
				lines.add(model07.toString());
            }
		}
        return lines;
    }

    @Override
    public Path buildPath() {
        File file = new File(getSource());
        return Paths.get(file.getParent(),getDist());
    }
}

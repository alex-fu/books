package com.wacai.fund.fs.schedule;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.utils.DateUtils;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * CleanDirectoryService
 *
 * @author mufu
 * @date 2017/11/22
 */
@Slf4j
@Service
public class CleanDirectoryService {
	
	@Autowired
	private PropertyService propertyService;

    @Scheduled(cron = "0 1 1 1 * ?")
    public void cleanDirectoryExecution() {
        Path path = Paths.get(propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH,"/data/program/download"));
        LocalDate lastMonth = LocalDate.now().minusMonths(1);

        List <Path> paths = new ArrayList <>();
        try (DirectoryStream <Path> directoryStream = Files.newDirectoryStream(path)) {
            directoryStream.forEach(paths::add);
            paths = paths.stream().filter(p -> p.toFile().isDirectory())
                    .filter(p -> lastMonth.isAfter(DateUtils.toLocalDate(p.getFileName().toString())))
                    .collect(Collectors.toList());
            paths.stream().forEach((p) -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException e) {
                    log.error("delete failed, reason ",e);
                }
            });
            log.info("delet expires directory successful!!!");
        } catch (IOException e) {
            log.error("delete expires directory failed, {}", e);
        }
    }

}

package com.wacai.fund.fs.schedule;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.utils.FileUtils;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.lang.utils.DateUtil;
import com.wacai.fund.parent.service.property.PropertyService;

import lombok.extern.slf4j.Slf4j;

/**
 * CreateDirectoryService
 *
 * @author mufu
 * @date 2017/11/22
 */
@Slf4j
@Service
public class CreateDirectoryService {
	
	@Autowired
	private PropertyService propertyService;

    @Scheduled(cron = "0 10 2 * * ?")
    public void createDirectoryExecution() {
        String directory = DateUtil.currentDate();
		try {
			Path path = Paths.get(propertyService.getString(PropertyConstant.FUND.FUND_FILE_DOWNLOAD_PATH, "/data/program/download"), directory);
			if (!path.toFile().exists()) {
				FileUtils.createDirectory(path);
				log.info("create directory {} successful!!!", directory);
			} else {
				log.info("directory {} exists!!!", directory);
			}
		} catch (IOException e) {
			log.error("create directory {} failed and reason {}", directory, e);
		}
    }
}

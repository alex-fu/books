package com.wacai.fund.fs.utils;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * DateUtils
 *
 * @author mufu
 * @date 2017/11/22
 */
@Slf4j
public class DateUtils {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyMMdd");

    private DateUtils() {
	}
    
    public static LocalDate toLocalDate(String date) {
        if (Strings.isNullOrEmpty(date)) {
            throw new NullPointerException();
        }
        return LocalDate.parse(date, DATE_TIME_FORMATTER);
    }

    public static String getCurrentDate() {
        return LocalDate.now().format(DATE_TIME_FORMATTER);
    }

    /**generate crontab expression**/
    public static String getCronWithDelays(long delays) {
        Instant today = Instant.now();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(today, ZoneId.systemDefault());
        LocalDateTime newlocalDateTime = localDateTime.plus(delays, ChronoUnit.SECONDS);
        int seconds = newlocalDateTime.getSecond();
        int minutes = newlocalDateTime.getMinute();
        int hour = newlocalDateTime.getHour();
        int day = newlocalDateTime.getDayOfMonth();
        int month = newlocalDateTime.getMonthValue();
        String cron = Joiner.on(" ").join(seconds, minutes, hour, day, month, "?");
        log.info("getCronWithDelays : cron== {}", cron);
        return cron;
    }
}

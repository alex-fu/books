package com.wacai.fund.fs.service.task;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.exception.FSException;

import java.util.List;

/**
 * FsTransactionPoService interface
 *
 * @author mufu
 * @date 2017/10/17
 */
public interface FsTransactionPoService {
    void createtTransaction(List<FsTemplatePo> templates) throws FSException;

    FsTransactionPo get(Long id);

    FsTransactionPo getByTaskId(String taskId);

    int update(FsTransactionPo fsTransactionPo);

    boolean isAvailable(String taskId);
}

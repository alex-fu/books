package com.wacai.fund.fs.service.builder;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.output.TradeConfirm;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.service.ta.TradeConfirmService;

import lombok.extern.slf4j.Slf4j;

/**
 * TradeConfirmFileBuilder
 *
 * @author mufu
 * @date 2017/11/21
 */
@Slf4j
@Service("tradeConfirmFileBuilder")
public class TradeConfirmFileBuilder extends AbstractFileBuilder {

    private static final Template TEMPLATE_04 = new Template(TAType.TA_04);

    private static final Template TEMPLATE_06 = new Template(TAType.TA_06);

    private static final TAParser TA_PARSER = TAParser.getInstance();

    private TABeans <TA> tab04;

    private TABeans <TA> tab06;


    @Autowired
    @Qualifier("tradeConfirmService04Impl")
    TradeConfirmService tcs1;

    @Autowired
    @Qualifier("tradeConfirmService06Impl")
    TradeConfirmService tcs2;


    private String newGenerateFile;


    @Override
    protected void check()throws Exception{
        String[] sources = getSource().split(",");

        String source04 = sources[0];
        String source06 = sources[1];
        log.info("source [{}-{}]",source04,source06);

        if (isEmpty(source04) || Files.notExists(Paths.get(source04))) {
            try {
                throw new FileNotFoundException("source file" + source04 + " not exists!!!");
            } catch (FileNotFoundException e) {
                log.error("source file {} not exists!!!", source04);
            }
        }
        if (isEmpty(source06) || Files.notExists(Paths.get(source06))) {
            try {
                throw new FileNotFoundException("source file" + source06 + " not exists!!!");
            } catch (FileNotFoundException e) {
                log.error("source file {} not exists!!!", source06);
            }
        }
    }

    @Override
    protected void init() {
    	String[] sources = getSource().split(",");

        String source04 = sources[0];
        String source06 = sources[1];
        tab04 = TA_PARSER.buildFromTA(source04, TEMPLATE_04);
        tab06 = TA_PARSER.buildFromTA(source06, TEMPLATE_06);
        log.info("TradeConfirm FileBuilder build init successful!!!");
    }

    @Override
    public List <String> fetch() {
        List <String> lines = new ArrayList <>();
        List <TradeConfirm> tc04 = tcs1.convert(tab04);
        List <TradeConfirm> tc06 = tcs2.convert(tab06);
        tc04.stream().map(TradeConfirm::toString).forEach(lines::add);
        tc06.stream().map(TradeConfirm::toString).forEach(lines::add);
        return lines;
    }

    @Override
    public Path buildPath() {
        File file = new File(getSource().split(",")[0]);
        Path path = Paths.get(file.getParent(), getDist());
        log.info("the file = {}", path.getFileName());
        newGenerateFile = path.toFile().getName();
        return path;
    }

    public String getPath() {
        return newGenerateFile;
    }

	public String getNewGenerateFile() {
		return newGenerateFile;
	}

	public void setNewGenerateFile(String newGenerateFile) {
		this.newGenerateFile = newGenerateFile;
	}
    
}

package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * Model06 class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model06 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4557899376425071136L;

	private BigDecimal BasisforCalculatingDividend;
	private String TransactionCfmDate;
	private String CurrencyType;
	private BigDecimal VolOfDividendforReinvestment;
	private String DividentDate;
	private BigDecimal DividendAmount;
	private String XRDate;
	private BigDecimal ConfirmedAmount;
	private String FundCode;
	private String RegistrationDate;
	private String ReturnCode;
	private String TransactionAccountID;
	private String DistributorCode;
	private String BusinessCode;
	private String TAAccountID;
	private BigDecimal DividendPerUnit;
	private String DefDividendMethod;
	private String DepositAcct;
	private String RegionCode;
	private String DownLoaddate;
	private BigDecimal Charge;
	private BigDecimal AgencyFee;
	private BigDecimal TotalFrozenVol;
	private BigDecimal NAV;
	private String BranchCode;
	private BigDecimal OtherFee1;
	private BigDecimal OtherFee2;
	private String IndividualOrInstitution;
	private BigDecimal DividendRatio;
	private String TASerialNO;
	private BigDecimal StampDuty;
	private BigDecimal FrozenBalance;
	private BigDecimal TransferFee;
	private String ShareClass;
	private String FeeCalculator;
	private BigDecimal DrawBonusUnit;
	private BigDecimal FrozenSharesforReinvest;
	private String DividendType;
	private String OriginalAppSheetNo;
	private BigDecimal AchievementPay;
	private BigDecimal AchievementCompen;

}

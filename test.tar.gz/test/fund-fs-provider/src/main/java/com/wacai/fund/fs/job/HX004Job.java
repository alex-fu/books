package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.HX004ProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.utils.DateUtils;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * TradeConfirmJob
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Component("hx004Job")
public class HX004Job implements Job {

	@Autowired
	HX004ProcessTemplate hx004ProcessTemplate;

	@Autowired
	FsTransactionPoService fsTransactionPoService;

	@Override
	public void execute(ExecuteContext executeContext) throws Throwable {
		log.info("----start to execution HX004Job Transaction------");
		long start = System.nanoTime();
		try {
			FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(generateTaskId());
			hx004ProcessTemplate.process(fsTransactionPo);
		} catch (Exception e) {
			log.error("HX004Job doExecute error,e=", e);
		}
		long end = System.nanoTime();
		log.info("----HX004Job finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end - start));
	}

	/** through the template to find transaction **/
	private String generateTaskId() {
		return DateUtils.getCurrentDate() + TaskType.TASK_6.getValue();
	}

}
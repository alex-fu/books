package com.wacai.fund.fs.service.task;

import com.wacai.fund.fs.exception.FSException;

/**
 * CreateDailyTransactionService
 *
 * @author mufu
 * @date 2017/11/23
 */
public interface CreateDailyTransactionService {

    /**
     * 初始化模版
     * @throws FSException
     */
    void createDailyTransaction();

}

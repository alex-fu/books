package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.fund.fs.service.task.CreateDailyTransactionService;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * DailyJob
 *
 * @author mufu
 * @date 2017/11/23
 */
@Slf4j
@Component("dailyJob")
public class DailyJob implements Job {

    @Autowired
    CreateDailyTransactionService createDailyTransactionService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution CreateDailyTransaction------");
        long start = System.nanoTime();
        try {
            createDailyTransactionService.createDailyTransaction();
        } catch (Exception e) {
        	BizMonitor.report(new MInfo(MtraceEnum.FS_TASK_INIT.getCode(), ActionEnum.CREATE_FILE_JOB.getCode(),
					ResultEnum.FAILED.getCode(), "文件系统任务模板初始化失败：" + e.getMessage()));
            log.error("DailyJob doExecute error,e=", e);
        }
        long end = System.nanoTime();
        log.info("----DailyJob finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end-start));
    }
}
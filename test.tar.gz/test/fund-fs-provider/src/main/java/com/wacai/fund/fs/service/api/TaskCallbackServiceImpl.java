package com.wacai.fund.fs.service.api;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.constant.TaConstant;
import com.wacai.fund.fs.mapper.FsTransactionMapper;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.parent.client.enums.FileSysOutputTypeEnum;
import com.wacai.fund.parent.client.result.Result;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * TaskCallbackServiceImpl
 *
 * @author mufu
 * @date 2017/11/21
 */
@Slf4j
@Service("taskCallbackService")
public class TaskCallbackServiceImpl implements TaskCallbackService {

    @Autowired
    FsTransactionMapper fsTransactionMapper;

    @Override
	public Result<Boolean> callback(String taskId, ConfirmType confirmType) {
		// TODO 这里的feedback需要支持：未确认0 成功 1／失败 2 ／重试 3 4种情况
		// TODO distributed lock
		Result<Boolean> result = new Result<>();
		FsTransactionPo fsTransactionPo = null;
		try {
			fsTransactionPo = fsTransactionMapper.selectByTaskId(taskId);
			Optional<FsTransactionPo> fsTransactionPoOptional = Optional.ofNullable(fsTransactionPo);
			if (!fsTransactionPoOptional.isPresent()) {
				result.setValue(false);
				result.setError("taskId not found", taskId);
				log.error("taskid= {} 任务找不到！", fsTransactionPo.getTaskId());
				doFileProcessMoitor(fsTransactionPo.getFileType(), fsTransactionPo.getFileType() + "_callback",
						ResultEnum.FAILED.getCode(), "任务找不到");
				return result;
			}
			if (ConfirmType.SUCCESS.getValue().equals(confirmType.getValue())) {
				fsTransactionPo.setConfirmStatus(confirmType.getValue());
			} else if (ConfirmType.FAILED.getValue().equals(confirmType.getValue())) {
				result.setError("taskId callback failed!");
				fsTransactionPo.setConfirmStatus(confirmType.getValue());
				log.error("taskid= {} 任务回调失败", fsTransactionPo.getTaskId());
				doFileProcessMoitor(fsTransactionPo.getFileType(), fsTransactionPo.getFileType() + "_callback",
						ResultEnum.FAILED.getCode(), "任务回调失败");
			} else if (ConfirmType.RETRY.getValue().equals(confirmType.getValue())) {
				// set to unconfirmed
				fsTransactionPo.setConfirmStatus(ConfirmType.UNCONFIRMED.getValue());
			}
			if (fsTransactionMapper.update(fsTransactionPo) > 0) {
				result.setValue(true);
				return result;
			} else {
				result.setValue(false);
				result.setError("taskId update failed!");
				log.error("taskId:{} update failed!", taskId);
				doFileProcessMoitor(fsTransactionPo.getFileType(), fsTransactionPo.getFileType() + "_callback",
						ResultEnum.FAILED.getCode(), "任务更新失败");
			}
		} catch (Exception e) {
			log.error("TaskCallbackServiceImpl.callback taskId:{} update failed!!!", taskId, e);
		}
		return result;
	}
    
	/**
	 * doFileProcessMoitor:文件系统任务处理监控
	 * @param fileType
	 * @param actionCode
	 * @param result
	 * @param message
	 * @author qingniu
	 * @date 2018年1月10日 下午3:23:32
	 */
	private void doFileProcessMoitor(Integer fileType, String actionCode, String result, String message) {
		String mtrace = "";
		String msg = "";
		String action = TaConstant.getMonitorActionMap().get(actionCode);
		// 账户确认文件
		if (Integer.valueOf(FileSysOutputTypeEnum.ACC_ACK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_02_TASK.getCode();
			msg = MtraceEnum.FS_02_TASK.getDesc() + message;
			// 交易申请文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TRA_APP.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_03_TASK.getCode();
			msg = MtraceEnum.FS_03_TASK.getDesc() + message;
			// 交易确认文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TRA_ACK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_04_06_TASK.getCode();
			msg = MtraceEnum.FS_04_06_TASK.getDesc() + message;
			// 份额确认文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.VOL_CHK.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_05_TASK.getCode();
			msg = MtraceEnum.FS_05_TASK.getDesc() + message;
			// 基金行情文件
		} else if (Integer.valueOf(FileSysOutputTypeEnum.TA_07.getCode()).equals(fileType)) {
			mtrace = MtraceEnum.FS_07_TASK.getCode();
			msg = MtraceEnum.FS_07_TASK.getDesc() + message;
		}
		log.info("mtrace =={};action =={};result =={};message =={};", mtrace, action, result, msg);
		if (StringUtils.isNotBlank(mtrace)) {
			BizMonitor.report(new MInfo(mtrace, action, result, msg));
		}
	}
}

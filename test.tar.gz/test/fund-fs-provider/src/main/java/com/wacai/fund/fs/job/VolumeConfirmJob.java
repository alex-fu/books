package com.wacai.fund.fs.job;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wacai.finance.share.fund.tradedt.FundTradeDayService;
import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.process.VolumeConfirmProcessTemplate;
import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import com.wacai.fund.fs.utils.TaskIdUtils;
import com.wacai.platform.prophet.client.Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;

import lombok.extern.slf4j.Slf4j;

/**
 * VolumeConfirmJob
 *
 * @author mufu
 * @date 2017/11/24
 */
@Slf4j
@Component("volumeConfirmJob")
public class VolumeConfirmJob implements Job {

    @Autowired
    VolumeConfirmProcessTemplate volumeConfirmProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;
    
    @Autowired
    FundTradeDayService fundTradeDayService;

    @Override
    public void execute(ExecuteContext executeContext) throws Throwable {
        log.info("----start to execution VolumeConfirmJob Transaction------");
        long start = System.nanoTime();
        try {
        	String taskId = generateTaskId();
			if (StringUtils.isNotBlank(taskId)) {
	            FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId(taskId);
	            volumeConfirmProcessTemplate.process(fsTransactionPo);
			}
        } catch (Exception e) {
            log.error("VolumeConfirmJob doExecute error", e);
        }
        long end = System.nanoTime();
        log.info("----VolumeConfirmJob finish----cost {} ms", TimeUnit.NANOSECONDS.toMillis(end-start));
    }


    /**
	 * generateTaskId:获取份额确认的任务id
	 * @return
	 * @author qingniu
	 * @date 2017年12月18日 下午7:43:07
	 */
	private String generateTaskId() {
		String taskId = "";
		try {
			String tradeDate = fundTradeDayService.calTradeDateByCurrentDate();
			//份额确认的前置条件是交易确认，如果交易确认未执行成功，不执行份额确认
			if (preCheckVolumeConfirm(tradeDate)) {
				taskId = TaskIdUtils.generateId(tradeDate, TaskType.TASK_3.getValue());
			}
			log.info("generateTaskId : tradeDate == {}; taskId == {}", tradeDate, taskId);
		} catch (Exception e) {
			log.error("generateTaskId happen Exception", e);
		}
		return taskId;
	}
	
	
	/**
	 * preCheckVolumeConfirm:份额确认前置校验，校验交易确认是否处理完成
	 * @param tradeDate
	 * @return
	 * @author qingniu
	 * @date 2018年1月8日 上午11:20:57
	 */
	private boolean preCheckVolumeConfirm(String tradeDate) {
		boolean preCheckFlag = false;
		String accountConfirmTaskId = TaskIdUtils.generateId(tradeDate, TaskType.TASK_2.getValue());
		FsTransactionPo fsTransaction = fsTransactionPoService.getByTaskId(accountConfirmTaskId);
		if (null != fsTransaction && fsTransaction.getFinishStatus()
				&& ConfirmType.SUCCESS.getValue().equals(fsTransaction.getConfirmStatus())) {
			preCheckFlag = true;
		}
		log.info("preCheckVolumeConfirm : tradeDate == {}; preCheckFlag == {}", tradeDate, preCheckFlag);
		return preCheckFlag;
	}
}
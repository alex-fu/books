package com.wacai.fund.fs.process;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.service.builder.HXFileBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;

/**
 * HX004ProcessTemplate
 *
 * @author mufu
 * @date 2017/11/28
 */
@Slf4j
@Service("hx011ProcessTemplate")
public class HX011ProcessTemplate extends BasicProcessTemplate {
    @Autowired
    HXFileBuilder hxFileBuilder;

    @Override
    public void parser(FsTransactionPo fsTransactionPo) {
		try {
			String source = getCurrentDirectory() + File.separator + fsTransactionPo.getDownloadFilePattern();
			String dist = fsTransactionPo.getUploadFilePattern();
			log.info("hx011ProcessTemplate.parser : source =={}", source);
			hxFileBuilder.build(source, dist);
		} catch (Exception e) {
			log.error("hx011ProcessTemplate.parser happen Exception", e);
		}
    }

    @Override
    public TaskType getType() {
        return TaskType.TASK_7;
    }
}

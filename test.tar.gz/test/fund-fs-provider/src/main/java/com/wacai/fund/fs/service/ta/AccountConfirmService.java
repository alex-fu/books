package com.wacai.fund.fs.service.ta;

import com.wacai.fund.fs.bean.output.AccountConfirm;
import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.ta.TA;

import java.util.List;

/**
 * AccountConfirmService interface
 *
 * @author mufu
 * @date 2017/10/7
 */
public interface AccountConfirmService {
    public List<AccountConfirm> convert(TABeans<TA> ta);
}

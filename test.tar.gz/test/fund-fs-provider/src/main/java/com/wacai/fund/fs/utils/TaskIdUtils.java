package com.wacai.fund.fs.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * TaskIdUtils
 *
 * @author mufu
 * @date 2017/11/17
 */
public class TaskIdUtils {

	private TaskIdUtils() {
	}
	
	/**
	 * generateId: 根据交易日期和任务类型获取任务id
	 * @param tradeDate
	 * @param taskType
	 * @return
	 * @author qingniu
	 * @date 2018年1月8日 上午11:29:17
	 */
	public static String generateId(String tradeDate, Integer taskType) {
		String taskId = "";
		if (StringUtils.isNoneBlank(tradeDate)) {
			taskId = tradeDate + taskType;
		}
		return taskId;
	}
}

package com.wacai.fund.fs.service.ta;

import java.util.List;

/**
 * @description: 获取生息宝基金列表
 * @author qingniu
 * @date 2017年12月11日 下午3:55:44
 * @since JDK 1.8
 */
public interface SxbFundFilterService {
	
    public List<String> getSxbFundList();

}

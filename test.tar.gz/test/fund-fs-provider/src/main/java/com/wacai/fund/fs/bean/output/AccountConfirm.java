package com.wacai.fund.fs.bean.output;

import java.io.Serializable;
import java.util.List;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import lombok.Data;

/**
 * AccountConfirm
 * from 02 file
 * from: OFD_152_99_20170704_03.TXT
 * to：fund_account_ack_${taCode}_${tradeDate}.txt
 *
 * @author mufu
 * @date 2017/11/03
 */
@Data
public class AccountConfirm implements Serializable{

    private static final long serialVersionUID = 7970599378772500483L;

    //TransactionCfmDate
    private String ackDate;
    //TransactionAccountID
    private String tradeAccount;
    //TAAccountID
    private String fundAccount;
    //retrieve from file
    private String taCode;
    //business code
    private String busiCode;
    //ReturnCode
    private String taRetCode;
    //Specification
    private String retMsg;

    @Override
    public String toString() {
        List <Object> list = Lists.newArrayList(this.ackDate, this.tradeAccount, this.fundAccount, this.taCode, this.busiCode,
                this.taRetCode, this.retMsg);
        return Joiner.on("|").useForNull("").join(list);
    }
}

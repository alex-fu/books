package com.wacai.fund.fs.process;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.service.builder.TA07FileBuilder;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * TA07ProcessTemplate
 *
 * @author mufu
 * @date 2017/11/28
 */
@Slf4j
@Service("ta07ProcessTemplate")
public class TA07ProcessTemplate extends BasicProcessTemplate {

    @Autowired
    TA07FileBuilder ta07FileBuilder;

    @Override
    public TaskType getType(){
        return TaskType.TASK_4;
    }

    @Override
    public void parser(FsTransactionPo task) {
    	try {
	    	String source = getCurrentDirectory()+ File.separator+ task.getDownloadFilePattern();
	        String dist = task.getUploadFilePattern();
	        log.info("TA07ProcessTemplate.parser : source =={}; dist =={}", source, dist);
			ta07FileBuilder.build(source, dist);
		} catch (Exception e) {
			BizMonitor.report(new MInfo(MtraceEnum.FS_07_TASK.getCode(), ActionEnum.FUND_INFO_PROCESS.getCode(), ResultEnum.FAILED.getCode(), "基金行情文件处理失败，解析失败"));
			log.error("TA07ProcessTemplate.parser happen Exception", e);
		}
    }
}

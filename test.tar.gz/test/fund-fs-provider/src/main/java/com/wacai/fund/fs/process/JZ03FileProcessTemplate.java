package com.wacai.fund.fs.process;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.enums.TaskType;
import com.wacai.fund.fs.service.builder.JZ03FileBuilder;
import com.wacai.fund.parent.monitor.BizMonitor;
import com.wacai.fund.parent.monitor.MInfo;
import com.wacai.fund.parent.monitor.enums.ActionEnum;
import com.wacai.fund.parent.monitor.enums.MtraceEnum;
import com.wacai.fund.parent.monitor.enums.ResultEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * AccountConfirmProcessTemplate
 *
 * @author mufu
 * @date 2017/11/27
 */
@Slf4j
@Service("jz03FileProcessTemplate")
public class JZ03FileProcessTemplate extends BasicProcessTemplate {

    @Autowired
    JZ03FileBuilder  jz03FileBuilder;

    @Override
    public void parser(FsTransactionPo fsTransactionPo){
    	try{
	        String source = getCurrentDirectory()+ File.separator+ fsTransactionPo.getDownloadFilePattern();
	        String dist = fsTransactionPo.getUploadFilePattern();
	        log.info("jz03FileProcessTemplate.parser : source =={}", source);
	        jz03FileBuilder.build(source, dist);
    	} catch (Exception e) {
			BizMonitor.report(new MInfo(MtraceEnum.FS_03_TASK.getCode(), ActionEnum.TRADE_APP_PROCESS.getCode(), ResultEnum.FAILED.getCode(), "交易申请文件处理失败，解析失败"));
			log.error("jz03FileBuilder.parser happen Exception", e);
		}
    }

    @Override
    public TaskType getType(){
        return TaskType.TASK_5;
    }
}

package com.wacai.fund.fs.client;

import com.jcraft.jsch.ChannelSftp;
import com.wacai.fund.parent.client.constant.PropertyConstant;
import com.wacai.fund.parent.client.exception.FundParentException;
import com.wacai.fund.parent.service.net.SFtpClientService;
import com.wacai.fund.parent.service.property.PropertyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;

/**
 * @author jingfan
 * @description: 华安SFTP
 * @date 2018/2/6 下午3:21
 * @since JDK 1.8
 */
@Slf4j
@Service
public class HuaAnSFTPTransfer implements Transfer {

    @Autowired
    private PropertyService propertyService;

    @Override
    public byte[] download(String folder, String fileName) throws Exception {
        log.info("huaan sftp execute download from {}/{}", folder,fileName);
        try {
            folder = folder + File.separator;
            String host = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_HOST);
            int port = propertyService.getInt(PropertyConstant.WELFARE.HUAAN_SFTP_PORT);
            String username = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_USERNAME);
            String password = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_PASSWORD);
            log.info("huaan SFTPTransfer file host = {} port = {}  ufileDir = {} fileName = {}", host,
                    port, folder, fileName);
            // 从华安SFTP下载文件
            ChannelSftp sftp = SFtpClientService.getSftpConnect(host, port, username, password);
            // 判断文件是否存在
            if (SFtpClientService.existFile(fileName, folder, sftp)) {
                log.info("huaan SFTPTransfer file is exist fileDir = {} fileName = {}", folder, fileName);
                return SFtpClientService.downloadAsByte(fileName, folder, sftp);
            } else {
                throw FundParentException.wrap("huaan sftp download fail failed");
            }
        } catch (Exception e) {
            log.error("huaan SFTPTransfer file download fileName = {} e = ", fileName, e);
            throw FundParentException.wrap("huaan sftp download fail failed");
        }
    }

    @Override
    public void upload(String folder, String fileName) throws Exception {
        log.info("huaan sftp execute upload to {}/{}", folder,fileName);
        try {
            String host = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_HOST);
            int port = propertyService.getInt(PropertyConstant.WELFARE.HUAAN_SFTP_PORT);
            String username = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_USERNAME);
            String password = propertyService.getString(PropertyConstant.WELFARE.HUAAN_SFTP_PASSWORD);
            log.info("huaan SFTPTransfer file host = {} port = {}  ufileDir = {} fileName = {}", host,
                    port, folder, fileName);
            // 从华夏SFTP下载文件
            ChannelSftp sftp = SFtpClientService.getSftpConnect(host, port, username, password);
            SFtpClientService.upload(folder, fileName, sftp);
        } catch (Exception e) {
            log.error("huaan SFTPTransfer file upload fileName = {} e = ", fileName, e);
            throw FundParentException.wrap("huaan sftp upload file failed");
        }
    }
}

package com.wacai.fund.fs.bean.ta;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * Model04 class
 * @author mufu
 * @date 2017/10/31
 */
@Data
public class Model04 implements TA, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3684217653414323193L;

	private String AppSheetSerialNo;
	private String TransactionCfmDate;
	private String CurrencyType;
	private BigDecimal ConfirmedVol;
	private BigDecimal ConfirmedAmount;
	private String FundCode;
	private String LargeRedemptionFlag;
	private String TransactionDate;
	private String TransactionTime;
	private String ReturnCode;
	private String TransactionAccountID;
	private String DistributorCode;
	private BigDecimal ApplicationVol;
	private BigDecimal ApplicationAmount;
	private String BusinessCode;
	private String TAAccountID;
	private String TASerialNO;
	private String BusinessFinishFlag;
	private BigDecimal DiscountRateOfCommission;
	private String DepositAcct;
	private String RegionCode;
	private String DownLoaddate;
	private BigDecimal Charge;
	private BigDecimal AgencyFee;
	private BigDecimal NAV;
	private String BranchCode;
	private String OriginalAppSheetNo;
	private String OriginalSubsDate;
	private BigDecimal OtherFee1;
	private String IndividualOrInstitution;
	private String RedemptionDateInAdvance;
	private BigDecimal StampDuty;
	private BigDecimal ValidPeriod;
	private BigDecimal RateFee;
	private BigDecimal TotalBackendLoad;
	private String OriginalSerialNo;
	private String Specification;
	private String DateOfPeriodicSubs;
	private String TargetDistributorCode;
	private String TargetBranchCode;
	private String TargetTransactionAccountID;
	private String TargetRegionCode;
	private String TransferDirection;
	private String DefDividendMethod;
	private BigDecimal DividendRatio;
	private BigDecimal Interest;
	private BigDecimal VolumeByInterest;
	private BigDecimal InterestTax;
	private BigDecimal TradingPrice;
	private String FreezingDeadline;
	private String FrozenCause;
	private BigDecimal Tax;
	private BigDecimal TargetNAV;
	private BigDecimal TargetFundPrice;
	private BigDecimal CfmVolOfTargetFund;
	private BigDecimal MinFee;
	private BigDecimal OtherFee2;
	private String OriginalAppDate;
	private BigDecimal TransferFee;
	private String FromTAFlag;
	private String ShareClass;
	private String DetailFlag;
	private String RedemptionInAdvanceFlag;
	private String FrozenMethod;
	private String OriginalCfmDate;
	private String RedemptionReason;
	private String CodeOfTargetFund;
	private BigDecimal TotalTransFee;
	private String VarietyCodeOfPeriodicSubs;
	private String SerialNoOfPeriodicSubs;
	private String RationType;
	private String TargetTAAccountID;
	private String TargetRegistrarCode;
	private String NetNo;
	private String CustomerNo;
	private String TargetShareType;
	private String RationProtocolNo;
	private String BeginDateOfPeriodicSubs;
	private String EndDateOfPeriodicSubs;
	private BigDecimal SendDayOfPeriodicSubs;
	private String Broker;
	private String SalesPromotion;
	private String AcceptMethod;
	private String ForceRedemptionType;
	private String AlternationDate;
	private String TakeIncomeFlag;
	private String PurposeOfPeSubs;
	private BigDecimal FrequencyOfPeSubs;
	private String PeriodSubTimeUnit;
	private BigDecimal BatchNumOfPeSubs;
	private String CapitalMode;
	private String DetailCapticalMode;
	private BigDecimal BackenloadDiscount;
	private String CombineNum;
	private BigDecimal RefundAmount;
	private BigDecimal SalePercent;
	private BigDecimal ManagerRealRatio;
	private BigDecimal ChangeFee;
	private BigDecimal RecuperateFee;
	private BigDecimal AchievementPay;
	private BigDecimal AchievementCompen;
	private String SharesAdjustmentFlag;
	private String GeneralTASerialNO;
	private BigDecimal UndistributeMonetaryIncome;
	private String UndistributeMonetaryIncomeFlag;
	private BigDecimal BreachFee;
	private BigDecimal BreachFeeBackToFund;
	private BigDecimal PunishFee;
	private String TradingMethod;
	private BigDecimal ChangeAgencyFee;
	private BigDecimal RecuperateAgencyFee;
	private String ErrorDetail;
	private String LargeBuyFlag;
	private BigDecimal RaiseInterest;
	private String FeeCalculator;
	private String ShareRegisterDate;

}

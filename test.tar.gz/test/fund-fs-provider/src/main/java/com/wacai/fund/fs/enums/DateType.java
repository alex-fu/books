package com.wacai.fund.fs.enums;

/**
 * @description: 日期类型枚举类（0-自然日；1-交易日;2-工作日）
 * @author qingniu
 * @date 2017年12月18日 下午8:08:21
 * @since JDK 1.8
 */
public enum DateType {
	
	NATURE_DT(0, "自然日"),
	TRADE_DT(1, "交易日"),
    WORK_DT(2, "工作日");

    private final Integer value;
    private final String desc;

    private DateType(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }
    
    public String getDesc() {
        return desc;
    }

    public static DateType getInstance(Integer value) {
        for (DateType dateType : values()) {
            if (dateType.value.equals(value)) {
                return dateType;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.service.builder.TA07FileBuilder;

/**
 * TA07ServiceTest
 *
 * @author mufu
 * @date 2017/12/01
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class TA07ServiceTest {

    @Autowired
    TA07FileBuilder ta07FileBuilder;

    @Test
    public void jz03Test(){
    	try {
    		ta07FileBuilder.build("/Users/mufu/Desktop/OFD_04_152_20180206_07.TXT","HJB.TXT");
	    } catch (Exception e) {
	    	System.out.println(e);
	        e.printStackTrace();
	    }
    }
}
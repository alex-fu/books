package com.wacai.fund.fs;

import com.wacai.fund.fs.service.api.FileTaskService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * InvokeTaskTest
 *
 * @author mufu
 * @date 2017/11/29
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class FileTaskServiceTest {

    @Autowired
    FileTaskService fileTaskService;

    @Test
    public void invokeTaskTest(){
    	try{
    		fileTaskService.doFileTask("201712181");
    	}catch (Exception e) {
    		System.out.println(e);
		}
    }
}

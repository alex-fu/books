package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.bean.core.TABeans;
import com.wacai.fund.fs.bean.core.TAParser;
import com.wacai.fund.fs.bean.core.Template;
import com.wacai.fund.fs.bean.ta.TA;
import com.wacai.fund.fs.client.BaseConfig;
import com.wacai.fund.fs.enums.TAType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = BaseConfig.class)
@SpringBootTest
public class TAParserTest {

    @Test
    public void ta02parserTest(){
        TAParser ta = TAParser.getInstance();
        Template template = new Template(TAType.TA_02);
        TABeans<TA> tab = ta.buildFromTA("/Users/David/Desktop/download/20171129/ODF_03_152_20171129_02.TXT", template);
//        tab.getTas().forEach(System.out::println);
        System.out.println(tab.getTa());
    }
}

package com.wacai.fund.fs;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.parent.service.net.FtpClientService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class FTPDownloadTest {

	@Autowired
    FtpClientService ftpClientService;
	
	@Test
	public void downloadTest() {
		try {
			boolean isLogin = ftpClientService.connect("172.16.55.6", 21, "ftpuser_recv", "SUpKyimS");
			System.out.println("isLogin ==" + isLogin);
			if (isLogin) {
				byte[] buff = ftpClientService.download("/20171218", "OFD_03_152_20171218_202.TXT");
				Assert.assertNotNull(buff);
				System.out.println("downloadTest : buff == " + new String(buff));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void uploadTest() {
		try {
			boolean isLogin = ftpClientService.connect("", 21, "", "");
			System.out.println("isLogin ==" + isLogin);
			if (isLogin) {
				ftpClientService.upload("/sztfile/20171205", "/Users/David/Desktop/ODF_03_152_20171117_02.TXT");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

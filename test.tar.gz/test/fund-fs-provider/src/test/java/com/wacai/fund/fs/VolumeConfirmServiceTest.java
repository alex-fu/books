package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.service.builder.VolumeConfirmFileBuilder;

/**
 * TradeConfirmServiceTest
 *
 * @author mufu
 * @date 2017/11/20
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class VolumeConfirmServiceTest {

    @Autowired
    VolumeConfirmFileBuilder volumeConfirmFileBuilder;

    @Test
    public void volumeConfirmService() throws Exception{
    	try {
    		volumeConfirmFileBuilder.build("/Users/David/Desktop/20171123/152/OFD_03_152_20171129_05.TXT","fund_vol_chk_03_20171129.txt");
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
    }
}

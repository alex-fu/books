package com.wacai.fund.fs;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.process.BasicProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * AccountConfirmProcessTest
 *
 * @author mufu
 * @date 2017/11/22
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class AccountConfirmProcessTest {
    @Autowired
    @Qualifier("accountConfirmProcessTemplate")
    BasicProcessTemplate accountConfirmProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Test
    public void accountConfirmTest() throws Exception {
        FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId("201711291");
		if (fsTransactionPo != null) {
			System.out.println(fsTransactionPo);
			accountConfirmProcessTemplate.process(fsTransactionPo);
		} else {
			System.out.println("fsTransactionPo is null");
		}
    }
}

package com.wacai.fund.fs;

import com.wacai.fund.fs.schedule.configuration.DynamicSchedule;
import com.wacai.fund.fs.utils.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * DynamicScheduleTest
 *
 * @author mufu
 * @date 2017/11/28
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class DynamicScheduleTest {
    @Autowired
    DynamicSchedule dynamicSchedule;

    @Test
    public void dynamicScheduleTest(){
    	try {
	        String cron = DateUtils.getCronWithDelays(10);
	        System.out.println(cron);
	        dynamicSchedule.setCron(cron);
	        dynamicSchedule.setRunnable(()->{System.out.println("-------");});
	        dynamicSchedule.start();
            Thread.sleep(20000);
        } catch (InterruptedException e) {
        	System.out.println(e);
            e.printStackTrace();
        }
    }
}

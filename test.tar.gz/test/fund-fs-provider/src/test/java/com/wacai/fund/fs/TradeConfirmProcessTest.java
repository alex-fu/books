package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.process.TradeConfirmProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;

/**
 * TradeConfirmProcessTest
 *
 * @author mufu
 * @date 2017/11/24
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class TradeConfirmProcessTest {

	@Autowired
	TradeConfirmProcessTemplate tradeConfirmProcessTemplate;

	@Autowired
	FsTransactionPoService fsTransactionPoService;

	@Test
	public void tradeConfirmProcessTemplateTest() throws Exception {
		try {
			FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId("201711294");
			if (fsTransactionPo != null) {
				System.out.println(fsTransactionPo);
				tradeConfirmProcessTemplate.process(fsTransactionPo);
			} else {
				System.out.println("fsTransactionPo is null");
			}
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}
}

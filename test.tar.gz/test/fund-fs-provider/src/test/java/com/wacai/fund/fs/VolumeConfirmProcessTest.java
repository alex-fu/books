package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.process.VolumeConfirmProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;

/**
 * AccountConfirmProcessTest
 *
 * @author mufu
 * @date 2017/11/22
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class VolumeConfirmProcessTest {
    @Autowired
    @Qualifier("volumeConfirmProcessTemplate")
    VolumeConfirmProcessTemplate volumeConfirmProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Test
    public void volumeConfirmTest() throws Exception {
        try {
        	FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId("201711293");
			if (fsTransactionPo != null) {
				System.out.println(fsTransactionPo);
				volumeConfirmProcessTemplate.process(fsTransactionPo);
			} else {
				System.out.println("fsTransactionPo is null");
			}
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
    }
}

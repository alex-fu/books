package com.wacai.fund.fs;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.CollectionUtils;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.exception.FSException;
import com.wacai.fund.fs.service.task.FsTemplatePoService;
import com.wacai.fund.fs.service.task.FsTransactionPoService;

/**
 * TaskTransactionServiceTest
 *
 * @author mufu
 * @date 2017/11/17
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class TaskTransactionServiceTest {

	@Autowired
	FsTemplatePoService fsTemplatePoService;

	@Autowired
	FsTransactionPoService fsTransactionPoService;

	@Test
	public void getAllTaskTemplateTest() throws FSException {
		try {
			List<FsTemplatePo> fsTemplatePoList = fsTemplatePoService.getAllTemplate();
			if (CollectionUtils.isEmpty(fsTemplatePoList)) {
				fsTransactionPoService.createtTransaction(fsTemplatePoList);
			} else {
				System.out.println("fsTemplatePoList is null");
			}
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}

}

package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.service.builder.AccountConfirmFileBuilder;

/**
 * TradeConfirmServiceTest
 *
 * @author mufu
 * @date 2017/11/20
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class AccountConfirmServiceTest {

    @Autowired
    AccountConfirmFileBuilder accountConfirmFileBuilder;


    @Test
    public void accountConfirmService() {
    	try{
    		accountConfirmFileBuilder.build("/Users/David/Desktop/hx/152/OFD_03_152_20171128_02.TXT","fund_acc_ack_03_20171128.TXT");
    	} catch (Exception e) {
        	System.out.println(e);
            e.printStackTrace();
        }
        
    }
}

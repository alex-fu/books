package com.wacai.fund.fs;

import com.wacai.fund.fs.bean.task.FsTemplatePo;
import com.wacai.fund.fs.service.task.FsTemplatePoService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * TaskTemplateTest
 *
 * @author mufu
 * @date 2017/11/17
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class TaskTemplateTest {

    @Autowired
    FsTemplatePoService fsTemplatePoService;


    @Test
    public void getAllTaskTemplateTest() {
        List<FsTemplatePo> fsTemplatePoList = fsTemplatePoService.getAllTemplate();
        System.out.println(fsTemplatePoList);
    }

}

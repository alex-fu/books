package com.wacai.fund.fs;

import com.wacai.fund.fs.client.BaseConfig;
import com.wacai.fund.fs.bean.core.Field;
import com.wacai.fund.fs.constant.TaConstant;
import com.wacai.fund.fs.enums.TAType;
import com.wacai.fund.fs.utils.TemplateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = BaseConfig.class)
@SpringBootTest
public class TaConstantTest {
    @Test
    public void readProfilesTest() {
        String file = TaConstant.getTaMap().get(TAType.TA_02);
        try {
            File ff = ResourceUtils.getFile(file);
            Assert.notNull(ff, "the template should be found!");
            List <String> lines = Files.readAllLines(ff.toPath());
			System.out.println("lines == " + lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void ta02Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_02);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 02 file field should equals 465", 465, length);
    }

    @Test
    public void ta03Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_03);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 03 file field should equals 665", 665, length);
    }

    @Test
    public void ta04Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_04);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 04 file field should equals 1170", 1170, length);
    }

    @Test
    public void ta05Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_05);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 05 file field should equals 191", 191, length);
    }

    @Test
    public void ta06Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_06);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 06 file field should equals 440", 440, length);
    }

    @Test
    public void ta07Test() {
        List <Field> fields = TemplateUtils.loadTemplate(TAType.TA_07);
        int length = 0;
        for (Field field : fields) {
            length += field.getLength();
        }
        assertEquals("the TA 07 file field should equals 972", 972, length);
    }
}

package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.parent.service.fog.FogFileUpDownService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class FogDownloadTest {

    @Autowired
    FogFileUpDownService fogFileUpDownService;


    @Test
    public void uploadTest() {
        try {
//            fogFileUpDownService.upload("D:\\demo\\ODF_152_03_20171213_03_JZ.TXT");
            fogFileUpDownService.upload("/Users/liaozhicheng/Downloads/HJB_WC_01_04_20180207.TXT");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Test
    public void downloadTest() {
        try {
//            byte[] buff = fogFileUpDownService.download("fund", "OFD_152_03_20171220_03_JZ.TXT");
            byte[] buff = fogFileUpDownService.download("fund", "OFD_03_152_20180117_07.TXT");
            System.out.println("download == "+new String(buff));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}

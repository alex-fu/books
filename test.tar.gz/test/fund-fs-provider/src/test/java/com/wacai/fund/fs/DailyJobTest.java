package com.wacai.fund.fs;

import com.wacai.fund.fs.job.DailyJob;
import com.wacai.platform.prophet.client.context.ExecuteContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jingfan
 * @description: 模板初始化测试类
 * @date 2018/2/7 上午9:19
 * @since JDK 1.8
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class DailyJobTest {

    @Autowired
    private DailyJob dailyJob;

    @Test
    public void execute() throws Throwable {
        ExecuteContext executeContext = new ExecuteContext();
        dailyJob.execute(executeContext);
    }
}

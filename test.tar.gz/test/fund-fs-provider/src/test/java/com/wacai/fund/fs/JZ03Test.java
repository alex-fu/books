package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.service.builder.JZ03FileBuilder;

/**
 * JZ03Test
 *
 * @author mufu
 * @date 2017/11/21
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class JZ03Test {

    @Autowired
    @Qualifier("jz03FileBuilder")
    JZ03FileBuilder jz03FileBuilder;

    @Test
    public void jz03Test(){
    	try{
    		jz03FileBuilder.build("/Users/David/Desktop/20171130/OFD_152_03_20171130_03_JZ.TXT","OFD_152_03_20171130_03.TX");
	    } catch (Exception e) {
	    	System.out.println(e);
	        e.printStackTrace();
	    }
    }
}

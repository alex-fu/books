package com.wacai.fund.fs;

import com.wacai.fund.fs.job.HA01Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jingfan
 * @description: 华安份额划转导出文件测试
 * @date 2018/2/7 上午10:00
 * @since JDK 1.8
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class HA01JobTest {

    @Autowired
    private HA01Job hA01Job;

    @Test
    public void execute() throws Throwable {
        ExecuteContext executeContext = new ExecuteContext();
        hA01Job.execute(executeContext);
    }
}

package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.client.SFTPTransfer;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class SFTPDownloadTest {

	@Autowired
	SFTPTransfer sFTPTransfer;
	
	@Test
	public void downloadTest() throws Exception{
		
	}

	@Test
	public void uploadTest(){
		
	}

}

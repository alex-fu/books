package com.wacai.fund.fs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wacai.fund.fs.bean.task.FsTransactionPo;
import com.wacai.fund.fs.process.JZ03FileProcessTemplate;
import com.wacai.fund.fs.service.task.FsTransactionPoService;

/**
 * AccountConfirmProcessTest
 *
 * @author mufu
 * @date 2017/11/22
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class JZ03ProcessTest {
    @Autowired
    @Qualifier("jz03FileProcessTemplate")
    JZ03FileProcessTemplate jz03FileProcessTemplate;

    @Autowired
    FsTransactionPoService fsTransactionPoService;

    @Test
    public void JZ03Test() throws Exception {
    	try{
	        FsTransactionPo fsTransactionPo = fsTransactionPoService.getByTaskId("201711295");
			if (fsTransactionPo != null) {
				System.out.println(fsTransactionPo);
				jz03FileProcessTemplate.process(fsTransactionPo);
			} else {
				System.out.println("fsTransactionPo is null");
			}
	    } catch (InterruptedException e) {
	    	System.out.println(e);
	        e.printStackTrace();
	    }
    }
}

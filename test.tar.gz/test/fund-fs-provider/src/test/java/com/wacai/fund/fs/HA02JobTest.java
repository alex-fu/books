package com.wacai.fund.fs;

import com.wacai.fund.fs.job.HA02Job;
import com.wacai.platform.prophet.client.context.ExecuteContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jingfan
 * @description: 华安份额划转结果文件测试类
 * @date 2018/2/7 上午10:02
 * @since JDK 1.8
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:META-INF/spring/spring-context.xml")
@SpringBootTest
public class HA02JobTest {

    @Autowired
    private HA02Job hA02Job;

    @Test
    public void execute() throws Throwable {
        ExecuteContext executeContext = new ExecuteContext();
        hA02Job.execute(executeContext);
    }
}

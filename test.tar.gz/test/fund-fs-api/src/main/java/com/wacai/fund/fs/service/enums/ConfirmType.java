package com.wacai.fund.fs.service.enums;

/**
 * ConfirmType
 *
 * @author mufu
 * @date 2017/11/29
 */
public enum ConfirmType {
    UNCONFIRMED(0, "未确认"),
    SUCCESS(1, "成功"),
    FAILED(2, "失败"),
    RETRY(0, "重试");


    private final Integer value;
    private final String type;

    private ConfirmType(Integer value, String type) {
        this.value = value;
        this.type = type;
    }

    public Integer getValue() {
        return value;
    }

    public String getType() {
        return type;
    }

    public static ConfirmType getInstance(Integer value) {
        for (ConfirmType type : values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException(String.valueOf(value));
    }
}

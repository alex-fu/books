package com.wacai.fund.fs.service.api;

import com.wacai.fund.fs.service.enums.ConfirmType;
import com.wacai.fund.parent.client.result.Result;

/**
 * TaskCallbackService
 *
 * @author mufu
 * @date 2017/11/21
 */
public interface TaskCallbackService {

    /**
     * 回调修改任务流水状态
     * @param taskId 任务ID
     * @param confirmType 处理结果:未确认0 成功 1／失败 2 ／重试 3 4种情况
     * @return
     */
    public Result<Boolean> callback(String taskId, ConfirmType confirmType);
}

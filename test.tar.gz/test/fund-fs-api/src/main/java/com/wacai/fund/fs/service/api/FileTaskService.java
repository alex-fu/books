package com.wacai.fund.fs.service.api;

import com.wacai.fund.parent.client.result.Result;

/**
 * InvokeTask
 *
 * @author mufu
 * @date 2017/11/28
 */
public interface FileTaskService {
    /**
     * 手动执行任务
     * @param taskId 任务ID
     * @return
     */
    public Result<Boolean> doFileTask(String taskId);
}

# 基金文件系统 fund-fs-mgmt

## 简介
`fund-fs-mgmt`是一个为基金项目中的的文件传输以及部分文件处理提供服务的系统

### 目前支持的传输方式

> * SFTP
> * FTP
> * Fog


### 基本工作流程
![](pics/fund-fs-mgmt.png)


### 消息和告警
![](pics/notification.png)

### 架构图
![](pics/architect.png)



```
. 文件处理完成，发消息通知sxb系统，等到确认
. 文件系统起定时任务去检查是否已经收到确认，如果收到，即完成
. 如果定时任务没有检查到收到的回执，重新起一个定时任务去检查
. 默认最多重复三次，如果还是没有确认，即发告警通知消息

```


### topic: fund-fs-mgmt

###

| 字段       | 类型   |  备注  |
| --------   | -----:  | :----:  |
| taCode     | String |   TA码    |
| tradeDate        |   String   |   交易日期 yyyyMMdd  |
| fileGroup        |    String   |  namespace  |
| fileName         |  String |  文件名|
| fileType         | Integer  |枚举|


```
/*==============================================================*/
/* Table: fs_bp_file_template                                   */
/*==============================================================*/
create table fs_bp_file_template
(
   id                   bigint unsigned not null auto_increment comment 'id',
   task_name            varchar(256) comment '任务名称',
   task_type            tinyint comment '任务类型',
   provider             tinyint comment '数据供应商
            1:文件系统，2:fog系统，3:金证，4:深证通，5:华夏',
   provider_path        varchar(256) comment '数据供应商目录',
   receiver             tinyint comment '数据消费者
            1:文件系统，2:fog系统，3:金证，4:深证通，5:华夏',
   receiver_path        varchar(256) comment '数据消费者目录',
   upload_status        tinyint comment '数据是否上传
            1:是，0:否',
   download_status      tinyint comment '数据是否下载
            1:是，0:否',
   day_type             tinyint comment '日期类型
            0-自然日，1-交易日，2-工作日',
   file_dt              tinyint comment '文件名日期规则',
   download_file_pattern varchar(512) comment '下载文件名',
   upload_file_pattern  varchar(512) comment '上传文件名',
   file_type            tinyint comment '文件类型
            1, TA02-账户确认文件,  
            2, TA03-交易申请文件,
            3, TA04&06-交易确认文件,
            4, TA05-份额对账文件,
            5, 华夏F004-T0赎回受理对账文件,
            6, 华夏F011-T0赎回打款对账文件,
            7, TA07-基金行情文件文件，
            8,JZ03-交易申请文件；',
   remark               varchar(128) comment '备注',
   execution_dt         varchar(64) comment '执行时间',
   wait_ack_time        int(11) comment '等待时间',
   status               tinyint default 1 comment '有效标志
            0：无效，1：有效',
   created_time         timestamp not null default CURRENT_TIMESTAMP comment '创建时间',
   updated_time         timestamp not null default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP comment '修改时间',
   primary key (id)
)
auto_increment = 28
ENGINE = InnoDB
DEFAULT CHARSET = utf8 comment 'FS_BP01文件任务模板表';


/*==============================================================*/
/* Table: fs_tp_file_transaction                                */
/*==============================================================*/
create table fs_tp_file_transaction
(
   id                   bigint unsigned not null auto_increment comment 'id',
   task_id              varchar(32) comment '任务ID',
   task_name            varchar(256) comment '任务名称',
   provider             tinyint comment '数据供应商
            1:文件系统，2:fog系统，3:金证，4:深证通，5:华夏',
   provider_path        varchar(256) comment '数据供应商目录',
   receiver             tinyint comment '数据消费者
            1:文件系统，2:fog系统，3:金证，4:深证通，5:华夏',
   receiver_path        varchar(256) comment '数据消费者目录',
   download_status      tinyint comment '数据是否下载
            1:是，0:否',
   upload_status        tinyint comment '数据是否上传
            1:是，0:否',
   download_file_pattern varchar(512) comment '下载文件名',
   upload_file_pattern  varchar(512) comment '上传文件名',
   file_type            tinyint comment '文件类型
            1, TA02-账户确认文件,  
            2, TA03-交易申请文件,
            3, TA04&06-交易确认文件,
            4, TA05-份额对账文件,
            5, 华夏F004-T0赎回受理对账文件,
            6, 华夏F011-T0赎回打款对账文件,
            7, TA07-基金行情文件文件，
            8,JZ03-交易申请文件；',
   finish_status        tinyint comment '是否完成
            1:是，0:否',
   confirm_status       tinyint comment '回执状态
            0:未确认，1:成功，2:失败，3:重试',
   wait_ack_time        int(11) comment '等待时间',
   lock_status          tinyint comment '是否锁定
            1:是，0:否',
   alert_status         tinyint comment '是否告警
            1:是，0:否',
   message              varchar(512) comment '通知消息体',
   created_time         timestamp not null default CURRENT_TIMESTAMP comment '创建时间',
   updated_time         timestamp not null default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP comment '修改时间',
   primary key (id)
)
auto_increment = 28
ENGINE = InnoDB
DEFAULT CHARSET = utf8 comment 'FS_TP01文件任务流水表';
```


```
INSERT INTO fs_bp_file_template (task_name,task_type,provider,provider_path,receiver,receiver_path,download_status,upload_status,day_type,file_dt,download_file_pattern,upload_file_pattern,file_type,remark,execution_dt,wait_ack_time,status,created_time,updated_time) VALUES ('02文件生产账户确认文件',1,4,'/root/test',2,'',1,1,1,0,'ODF_03_152_{0}_02.TXT','fund_acc_ack_03_{0}.txt',1,'download 深证通02文件','0 15/30 4-7 * * ?',300,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO fs_bp_file_template (task_name,task_type,provider,provider_path,receiver,receiver_path,download_status,upload_status,day_type,file_dt,download_file_pattern,upload_file_pattern,file_type,remark,execution_dt,wait_ack_time,status,created_time,updated_time) VALUES ('04、06生产交易确认文件',2,4,'/root/test',2,'',1,1,1,0,'ODF_03_152_{0}_04.TXT,ODF_03_152_{0}_06.TXT','fund_trade_ack_03_{0}.txt',2,'download 深证通04文件，深证通06文件','0 15/30 9-10 * * ?',300,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO fs_bp_file_template (task_name,task_type,provider,provider_path,receiver,receiver_path,download_status,upload_status,day_type,file_dt,download_file_pattern,upload_file_pattern,file_type,remark,execution_dt,wait_ack_time,status,created_time,updated_time) VALUES ('05文件生产份额对账文件',3,4,'/root/test',2,'',1,1,1,0,'ODF_03_152_{0}_05.TXT','fund_vol_chk_03_{0}.txt',4,'download 深证通04文件','0 15/30 19-20 * * ?',300,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO fs_bp_file_template (task_name,task_type,provider,provider_path,receiver,receiver_path,download_status,upload_status,day_type,file_dt,download_file_pattern,upload_file_pattern,file_type,remark,execution_dt,wait_ack_time,status,created_time,updated_time) VALUES ('07文件',4,4,'/root/test',2,'',1,1,1,0,'ODF_03_152_{0}_07.TXT','ODF_03_152_{0}_07.TXT',7,'download 深证通07文件','',600,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO fs_bp_file_template (task_name,task_type,provider,provider_path,receiver,receiver_path,download_status,upload_status,day_type,file_dt,download_file_pattern,upload_file_pattern,file_type,remark,execution_dt,wait_ack_time,status,created_time,updated_time) VALUES ('03jz文件',5,2,'fund',3,'/root/jz/',1,1,1,-1,'ODF_152_03_{0}_03_JZ.TXT','ODF_152_03_{0}_03.TXT',8,'upload03JZ文件','',600,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
```
